# ADR-0002: Use the C4 Model with Mermaid to Diagram Architecture and Associate Diagrams with ADRs

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Principal Engineers, Platform Tech Leads |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0001 (adoption of ADRs), C4 Architecture Diagram Standard (reference document) |

## Context and Problem Statement

ADR-0001 establishes that decisions and their rationale are recorded in text. Text alone does not communicate structural change. Reviewers and future readers need to see what the architecture looked like before a decision and what it looks like after. How do we standardize architecture diagrams so they are consistent across teams, versionable alongside the decisions that changed them, and maintainable without specialized tooling?

If no decision is made, each team diagrams in its own tool and notation. Diagrams become unversioned image exports that drift from reality, cannot be diffed in review, and cannot be reliably associated with the decisions that produced them.

## Decision Drivers

- Diagrams must use a shared abstraction model so a reader can move between systems without relearning notation
- Diagram source must be text, so it lives in version control, renders in the repository, and diffs in pull requests
- Diagrams must be attachable to ADRs so structural change is captured at the moment of decision
- Tooling must render natively in the platforms teams already use, without a separate diagram server or licensed desktop tool
- Notation must scale down: a lightweight decision needs a lightweight diagram

## Options Considered

### Option 1: Freeform diagramming (draw.io, Visio, slides)

Teams continue producing visual diagrams in general-purpose tools.

- **Pros:** No learning curve; maximum expressive freedom
- **Cons:** No shared abstraction model; binary or XML artifacts do not diff meaningfully; exports drift from source; no reliable association with ADRs
- **Risks:** High. This is the current state the decision exists to correct

### Option 2: C4 model with Structurizr DSL

Adopt C4 as the abstraction model with Structurizr DSL as the canonical diagrams-as-code format.

- **Pros:** One model generates all C4 levels; strongest guarantee of cross-level consistency; purpose-built for C4
- **Cons:** Requires a rendering toolchain teams must install or host; does not render natively in the repository platform; steeper learning curve creates adoption friction for a lightweight per-ADR workflow
- **Risks:** Adoption stalls at the teams with the least diagramming culture, which are exactly the teams the standard most needs to reach

### Option 3: C4 model with Mermaid as the diagram language

Adopt C4 as the abstraction model (Context, Container, Component, and Code levels) with Mermaid as the standard diagram language, following the organizational C4 Architecture Diagram Standard.

- **Pros:** Mermaid renders natively in the repository platform and in ADR Markdown files, so the diagram source is the artifact; text source diffs in pull requests; C4 gives the shared zoom-level abstraction; lowest barrier to entry of the diagrams-as-code options
- **Cons:** Mermaid's C4 support is less rigorous than Structurizr; cross-level consistency is maintained by convention rather than generated from one model
- **Risks:** Convention-based consistency can erode; mitigated by the notation rules in the C4 standard and review checklists

## Decision

We will use the C4 model as the organizational standard for architecture diagrams, with Mermaid as the standard diagram language, and every ADR that changes system structure will include or reference the affected C4 diagrams.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** C4 provides the shared abstraction model with defined zoom levels. Mermaid satisfies text source, native rendering, and in-ADR embedding fully. The combination satisfies the scale-down driver: a small decision can carry a single Container diagram inline in its ADR.
- **Why the alternatives lost:** Option 1 was rejected because freeform diagrams cannot be versioned, diffed, or reliably tied to decisions. Option 2 was rejected because Structurizr's toolchain requirement and learning curve are friction precisely where adoption is most fragile; native rendering was judged more valuable than generated cross-level consistency at this stage of the organization.
- **Tradeoffs accepted deliberately:** We accept weaker enforced consistency across C4 levels in exchange for zero-toolchain rendering and lower adoption cost. Consistency is carried by the notation rules in the C4 Architecture Diagram Standard: title with level, full labels, one concern per diagram.
- **Assumptions this rests on:** Assumes the repository platform continues to render Mermaid natively. Assumes the C4 Architecture Diagram Standard remains the governing notation reference. If diagram scale or consistency demands outgrow convention, revisit Structurizr as a canonical model layer with Mermaid retained for ADR-embedded views.

## Consequences

### Positive

- Structural change is visible and reviewable in the same pull request as the decision that caused it
- One notation across all teams and portfolios
- Diagram history is preserved with decision history; "as-was" and "to-be" states are recoverable

### Negative

- Cross-level consistency depends on discipline and review rather than tooling
- Teams with existing Structurizr or draw.io investments must migrate or maintain exports

### Neutral / Follow-on Work

- Distribute the C4 Architecture Diagram Standard, including the worked four-level example and Mermaid templates
- Each system's owning team establishes its canonical diagram set in its repository
- Add the diagram checklist to ADR review: Mermaid source committed, image is an export and not the source, title states the C4 level

## Conformance and Validation

ADRs that change system structure without an associated C4 diagram are returned in review. Architecture reviews sample canonical diagram sets against deployed reality; drift is a finding. The pre-review checklist in the C4 standard is applied to diagram-bearing pull requests.

## Notes

Governing reference: C4 Architecture Diagram Standard (c4-architecture-standard), which defines notation rules, the four-level worked example, and Mermaid templates for ADR-embedded diagrams.
