# ADR-0003: Use Domain-Driven Design to Build Capability Platforms as the Integrated Service Layer for All Applications

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Principal Engineers, Platform Tech Leads, Central Engineering |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0006 (Platforma is built per this ADR), ADR-0008 (authentication and authorization externalized as an enterprise capability) |

## Context and Problem Statement

The converged organization inherited multiple applications that each built their own versions of common capabilities: search, geospatial services, entity resolution, notifications, document processing, and more. The same business capability is implemented several times, behind several APIs, with several data models, each maintained by a different team. How do we structure shared capabilities so that applications compose them rather than rebuild them, and how do we decide where one capability ends and another begins?

If no decision is made, every new application adds another copy of each capability it needs. Duplication compounds: sustainment cost multiplies, behavior diverges across apps, and any cross-cutting change (a security mandate, a data model correction, a governance control) must be executed once per copy.

## Decision Drivers

- Eliminate duplicative services and duplicated engineering effort across application portfolios
- Capability boundaries must be principled and durable, not accidents of team structure or delivery sequencing
- Applications must be able to compose capabilities through stable contracts without coordinating internals
- A shared service layer must be governable: cross-cutting controls land once, in the platform, not per application
- The model must scale to agentic workflows, where duplicated ungoverned services become unmanageable

## Options Considered

### Option 1: Application-owned services (status quo)

Each application team builds and owns the services it needs.

- **Pros:** Teams move independently; no cross-team dependency for new capability
- **Cons:** N implementations of every common capability; divergent behavior and data models; sustainment cost scales with application count; cross-cutting mandates become fleet-wide retrofits
- **Risks:** High and compounding, and disqualifying once agents consume services: duplicated service surfaces cannot be governed coherently

### Option 2: Shared code libraries

Extract common logic into libraries that application teams embed.

- **Pros:** Reduces some duplicated code; no runtime dependency between teams
- **Cons:** Libraries version-skew across consumers; data remains fragmented per application; behavior still diverges as teams fork or pin versions; governance controls cannot be enforced at a library boundary
- **Risks:** The duplication moves from code to deployment and data. The consolidation is cosmetic

### Option 3: Capability platforms designed with Domain-Driven Design

Build shared capabilities as productized platform services, one per business capability, with boundaries defined by DDD practice: bounded contexts derived from the domain, a ubiquitous language per context, and explicit context mapping between platforms and their consumers. Applications consume capabilities through published contracts.

- **Pros:** One implementation per capability, consumed by all applications; boundaries follow the domain rather than the org chart, so they survive reorganization; contracts and context maps make integration explicit and reviewable; governance controls attach once at the platform layer; the productized service layer is the precondition for governed agentic work
- **Cons:** Requires upfront domain analysis and ongoing boundary stewardship; application teams take a dependency on platform teams; capability platforms must be resourced and operated as products, not side projects
- **Risks:** Poorly drawn bounded contexts create coupling worse than duplication; mitigated by Architecture Council review of context boundaries and by treating boundary changes as ADR-worthy decisions

## Decision

We will build shared capabilities as capability platforms designed using Domain-Driven Design, forming a single integrated service layer that all applications leverage, with bounded contexts as the unit of platform boundary and published contracts as the means of consumption.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** One platform per capability eliminates duplication by construction. DDD bounded contexts satisfy the principled-boundaries driver: boundaries are derived from the domain model, not from which team happened to build first. Published contracts satisfy composability. A single service layer satisfies governability and is the stated precondition for governed agentic workflows.
- **Why the alternatives lost:** Option 1 was rejected because it is the duplication problem itself, and it becomes ungovernable when agents are consumers. Option 2 was rejected because libraries consolidate code while leaving data, deployment, and behavior fragmented, and because governance cannot be enforced at a compile-time boundary.
- **Tradeoffs accepted deliberately:** We accept cross-team dependencies on platform teams as the price of single implementations, and we commit to operating capability platforms as products with roadmaps, service levels, and consumer engagement so those dependencies are tolerable. We accept the cost of domain analysis upfront because boundary mistakes are far more expensive to correct after consumers integrate.
- **Assumptions this rests on:** Assumes capability platforms are resourced as products under the central engineering and portfolio structure. Assumes an Architecture Council exists to adjudicate bounded context boundaries. Assumes the productization standard defines what "published contract" means. If platforms cannot be resourced as products, revisit before consumers accumulate.

## Consequences

### Positive

- Each business capability is built once and consumed everywhere
- Cross-cutting mandates are implemented at the platform layer, once
- Boundaries survive reorganizations because they are anchored to the domain
- The service layer becomes the governed surface for agentic consumption

### Negative

- Platform teams become delivery dependencies for application teams
- Domain analysis and context mapping are real, ongoing work
- Existing duplicated services require a rationalization and migration effort

### Neutral / Follow-on Work

- Produce the initial context map: capability inventory, bounded contexts, and owning teams
- Define the productization standard requirements for a service to qualify as a capability platform
- Sequence rationalization of duplicated inherited services per portfolio
- Bounded context boundary changes require an ADR referencing this record

## Conformance and Validation

New services proposing to implement a capability that exists in the platform layer are challenged in architecture review; building a duplicate requires an exception ADR with an expiry. The context map is the authoritative register of capability boundaries and is reviewed by the Architecture Council. Platform conformance to the productization standard is assessed before consumers onboard.

## Notes

This record operationalizes the capability platforms strategy: duplicated service layers are the alternative being retired, and the productized service layer is the foundation that ADR-0006 (Platforma) and ADR-0008 (externalized authentication and authorization) build upon.
