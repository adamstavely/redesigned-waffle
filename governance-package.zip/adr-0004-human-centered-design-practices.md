# ADR-0004: Use Human-Centered Design and Development Practices Across All Product Work

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Experience Design Engineering, Principal Engineers, Portfolio Leads |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0007 (Trenchcoat design system implements this practice at the component level) |

## Context and Problem Statement

The organization builds software for operators and analysts whose work is high-consequence and time-constrained. Inherited systems show the familiar failure pattern: technically capable software that users work around, under-adopt, or abandon because it was built from the system's perspective rather than the user's. How do we ensure that what we build is shaped by and validated with the people who will use it, rather than driven by what is technically interesting or convenient to build?

If no decision is made, teams default to technology-first delivery. Requirements arrive as feature lists detached from workflow reality, usability is discovered at deployment, and the cost of misfit software is paid by end users in workarounds and by the organization in rework and failed adoption.

## Decision Drivers

- Software must fit real workflows; misfit in this mission context costs time, trust, and operational outcomes
- Users must be engaged throughout delivery, not consulted once at requirements and again at acceptance
- The practice must be teachable and repeatable across a converged organization with uneven design maturity
- Design and development must be integrated: designers embedded in delivery, not a separate handoff stage
- The practice must guard against tech-for-tech's-sake investment by tying build decisions to validated user need

## Options Considered

### Option 1: Requirements-driven delivery (status quo)

Build to documented requirements; validate at acceptance testing.

- **Pros:** Familiar; contractually clean; minimal process change
- **Cons:** Requirements documents are lossy proxies for user need; validation arrives after the cost is sunk; users experience the product only when it is expensive to change
- **Risks:** High. This is the pattern that produced the under-adopted inherited systems

### Option 2: Ad hoc user feedback

Encourage teams to talk to users, without a defined practice or checkpoints.

- **Pros:** Low ceremony; some teams will do it well
- **Cons:** Unenforceable and uneven; feedback quality depends on individual initiative; no shared methods, artifacts, or vocabulary across the converged organization; no gate that catches teams that skip it
- **Risks:** Regression to Option 1 under delivery pressure, team by team

### Option 3: Human-centered design and development as standard practice

Adopt HCD as the organizational standard: user research and workflow understanding before build, design studios and prototyping with users during build, usability validation as a delivery gate, and designers embedded in delivery teams through the experience design engineering portfolio.

- **Pros:** User contact is structural, not optional; shared methods and vocabulary across all teams; problems are found in prototypes where they are cheap, not in production where they are expensive; build investment is anchored to validated need
- **Cons:** Research and validation take calendar time; requires design capacity allocated across delivery teams; teams unfamiliar with HCD need enablement
- **Risks:** HCD performed as ritual rather than practice, producing artifacts without insight; mitigated by embedding designers in teams rather than reviewing from outside, and by gating on evidence of user validation rather than presence of documents

## Decision

We will use human-centered design and development practices as the standard for all product work: building with and for the end user, with user engagement structured into every phase of delivery.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** Structured user engagement across the lifecycle satisfies workflow fit and continuous engagement. A defined practice with shared methods satisfies repeatability across converged teams. The experience design engineering portfolio satisfies integration by embedding design in delivery. Gating build investment on validated user need is the direct control against tech for tech's sake.
- **Why the alternatives lost:** Option 1 was rejected because requirements documents systematically fail to capture workflow reality, and this organization's inheritance is the evidence. Option 2 was rejected because an unenforced practice is not a practice; it is a hope, and it collapses first in exactly the teams that need it most.
- **Tradeoffs accepted deliberately:** We accept the calendar cost of research and validation because it is smaller than the cost of building the wrong thing well. We accept that design capacity is a constrained resource to be allocated deliberately across portfolios rather than assuming every team self-serves.
- **Assumptions this rests on:** Assumes the experience design engineering portfolio is staffed to embed across delivery teams. Assumes user access can be arranged in the operating environment; where direct access is constrained, proxy-user and operational-SME arrangements must be explicit and acknowledged as weaker evidence. If user access becomes systematically unavailable, revisit the validation gate design rather than quietly waiving it.

## Consequences

### Positive

- Software fits the workflows it serves; adoption replaces workaround
- Misfit is discovered in prototypes, not production
- A shared design vocabulary and method set across the converged organization
- Build investment is defensible in terms of validated user need

### Negative

- Research and validation add elapsed time to delivery phases
- Design capacity becomes a scheduling constraint
- Enablement effort for teams new to HCD

### Neutral / Follow-on Work

- Publish the HCD practice guide: methods, checkpoints, and evidence expectations per delivery phase
- Define the user validation gate criteria used in reviews
- Stand up enablement (training, design studio facilitation) for converged teams
- ADR-0007 carries this practice into the component and pattern level through the Trenchcoat design system

## Conformance and Validation

Delivery reviews require evidence of user engagement appropriate to phase: research artifacts before build, usability findings before release. Absence of user validation evidence is a finding. Adoption and workflow-fit signals (usage, workaround reports, user feedback channels) are reviewed per product as trailing indicators.

## Notes

The test this record exists to enforce: every significant build decision should be able to answer "which user, doing what work, validated that this helps." Decisions that cannot answer it are tech for tech's sake by definition.
