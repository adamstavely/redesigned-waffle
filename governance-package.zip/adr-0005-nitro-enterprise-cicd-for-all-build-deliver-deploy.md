# ADR-0005: Use the Enterprise CI/CD Pipeline (Nitro) for All Software Build, Delivery, and Deployment

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Principal Engineers, Platform Tech Leads, Nitro platform team |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0001 (adoption of ADRs), ADR-0006 (Platforma; Nitro is the required deployment path to Platforma) |

## Context and Problem Statement

The converged organization inherited multiple build and deployment toolchains: team-managed pipelines with differing runners, scripts, security scanning coverage, artifact stores, and deployment mechanisms. This fragmentation multiplies sustainment cost, produces inconsistent security posture, and makes software delivery unauditable at the enterprise level. How should software be built, delivered, and deployed across the organization?

If no decision is made, every team continues to own a bespoke pipeline, and every audit, security mandate, or platform migration must be executed N times across N variants.

## Decision Drivers

- Consistent, centrally maintained security gates: scanning, signing, provenance, and policy enforcement applied to every build without per-team implementation
- Auditability of the path from source to production for every deployed artifact
- Sustainment cost: pipeline maintenance should be a platform concern, not duplicated engineering effort in every team
- Team onboarding: converged teams need one delivery path to learn, not a survey of local customs
- Compliance obligations of the operating environment must be satisfiable at the pipeline layer, once

## Options Considered

### Option 1: Team-managed pipelines (status quo)

Each team continues to own and operate its inherited CI/CD tooling.

- **Pros:** No migration cost; teams keep tooling they know; maximum local flexibility
- **Cons:** Security controls are implemented unevenly or not at all; no enterprise-level provenance; duplicated maintenance across dozens of pipelines; every new mandate is a fleet-wide retrofit
- **Risks:** High and compounding. The cost of fragmentation grows with each new compliance requirement and each new team

### Option 2: Hybrid model (Nitro for production, team pipelines permitted for development builds)

Mandate Nitro for release and deployment, allow local pipelines for pre-release stages.

- **Pros:** Softer migration; teams keep fast local feedback loops
- **Cons:** Two systems to keep in sync; the security and provenance guarantees only attach at the end of the path, so what was tested is not what is guaranteed; ambiguity about where the boundary sits invites drift back to fragmentation
- **Risks:** The hybrid boundary erodes. Exceptions become the norm and the organization pays for both models

### Option 3: Nitro for all build, delivery, and deployment

Mandate the enterprise CI/CD pipeline as the single path for all software: every build, every artifact, every deployment.

- **Pros:** Security gates, signing, and provenance applied uniformly and maintained once by the platform team; complete source-to-production audit trail; one delivery model to onboard against; enterprise mandates land in one place
- **Cons:** Migration effort for every inherited pipeline; teams lose local pipeline customizations; Nitro becomes a single point of dependency for all delivery; Nitro's feature set constrains what teams can do
- **Risks:** Nitro capability gaps or capacity limits block teams. Mitigated by a formal gap-escalation path to the Nitro platform team and by treating Nitro capacity as a platform obligation

## Decision

We will use the enterprise CI/CD pipeline, Nitro, for all software build, delivery, and deployment across the organization.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** Fully satisfies uniform security gates, auditability, and single-onboarding-path. Satisfies the sustainment driver by converting N team pipelines into one platform-maintained capability. Satisfies compliance by making the pipeline the enforcement point, implemented once.
- **Why the alternatives lost:** Option 1 was rejected because it is the fragmentation this organization was converged to eliminate; its costs grow with every mandate. Option 2 was rejected because a guarantee that attaches only at the final stage is a weaker guarantee, and because boundary ambiguity predictably erodes into de facto fragmentation, which is Option 1 with extra steps.
- **Tradeoffs accepted deliberately:** We accept migration cost now to avoid perpetual duplicated maintenance. We accept Nitro as a single point of dependency, on the grounds that a well-resourced shared dependency is preferable to dozens of under-resourced independent ones. We accept reduced local flexibility; teams needing capabilities Nitro lacks raise gaps through the escalation path rather than building around the pipeline.
- **Assumptions this rests on:** Assumes Nitro is resourced as an enterprise platform with capacity for the full organization's build volume. Assumes a functioning gap-escalation and prioritization process with the Nitro platform team. Assumes Nitro's compliance accreditation remains current. If any of these fail materially, this ADR should be revisited rather than worked around.

## Consequences

### Positive

- Every deployed artifact carries uniform scanning, signing, and provenance
- Enterprise-wide audit of the delivery path becomes a query, not a project
- New and converged teams onboard to one delivery model
- New security mandates are implemented once, at the platform layer

### Negative

- One-time migration effort for every inherited pipeline
- Loss of team-specific pipeline customizations
- Delivery velocity is coupled to Nitro capacity and responsiveness

### Neutral / Follow-on Work

- Publish a migration sequence and target dates per portfolio
- Establish the Nitro gap-escalation path and service expectations with the platform team
- Define the exception process: any deviation from Nitro requires its own ADR with an expiry date

## Conformance and Validation

Production deployment credentials are issued only to Nitro. Artifacts without Nitro provenance are not deployable. Architecture reviews verify no shadow pipelines exist; any discovered shadow pipeline is a finding with a remediation date. Migration progress is tracked per portfolio until inherited pipelines are decommissioned.

## Notes

Exceptions are expected to be rare, time-boxed, and documented as ADRs referencing this record so the reasoning for each deviation is as durable as the rule itself.
