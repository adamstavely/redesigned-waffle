# ADR-0006: Adopt Platform Engineering with Platforma as the Internal Developer Platform

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Principal Engineers, Central Engineering, Nitro platform team, Platforma platform team |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0003 (Platforma is built using domain-driven design), ADR-0005 (Nitro is the required deployment path to Platforma) |

## Context and Problem Statement

Application teams across the converged organization each carry their own infrastructure burden: environment provisioning, runtime configuration, observability wiring, secrets handling, and golden-path assembly. This undifferentiated work is duplicated per team, done to varying standards, and steals capacity from mission delivery. How do we provide engineering teams a paved road from code to running service so that infrastructure expertise is concentrated once and consumed everywhere?

If no decision is made, every team continues to be its own platform team. Infrastructure practices diverge, security posture varies with team skill, onboarding a new team means teaching a new bespoke stack, and senior engineering capacity is consumed by plumbing.

## Decision Drivers

- Concentrate infrastructure and operational expertise once, as a product, rather than diluting it across every team
- Golden paths: the secure, compliant, observable way to run a service should also be the easiest way
- Developer self-service: teams provision what they need without tickets and queues
- Consistency of runtime posture (security, observability, resilience) across everything the organization operates
- Coherence with the existing architecture: the platform must respect ADR-0003 (capability platform boundaries) and ADR-0005 (Nitro as the sole delivery path)

## Options Considered

### Option 1: Team-managed infrastructure (status quo)

Each team provisions and operates its own infrastructure on the underlying enterprise environment.

- **Pros:** Full team autonomy; no platform dependency
- **Cons:** Duplicated infrastructure work in every team; divergent security and observability posture; onboarding cost per bespoke stack; senior capacity spent on undifferentiated plumbing
- **Risks:** High and compounding, with posture variance as the sharpest edge in this operating environment

### Option 2: Central infrastructure team with ticket-based provisioning

Concentrate infrastructure in one team that fulfills requests from application teams.

- **Pros:** Expertise concentrated; consistent provisioning
- **Cons:** The central team becomes a queue; delivery velocity across the organization is coupled to ticket throughput; the model scales by adding headcount to the bottleneck
- **Risks:** The queue becomes the constraint on everything, and teams route around it, recreating Option 1 in the shadows

### Option 3: Platform engineering with an internal developer platform (Platforma)

Establish platform engineering as a discipline and Platforma as the organization's internal developer platform: self-service golden paths for provisioning, runtime, observability, and operations, operated as a product with application teams as its customers. Deployment to Platforma occurs exclusively through Nitro (ADR-0005). Platforma itself is designed using domain-driven design (ADR-0003), with its internal capabilities structured as bounded contexts behind published contracts.

- **Pros:** Expertise concentrated and consumed through self-service rather than queues; golden paths make the compliant way the easy way; uniform runtime posture by construction; platform-as-product framing keeps Platforma accountable to its users; DDD structure keeps the platform itself composable and governable
- **Cons:** Platforma must be resourced and operated as a real product; teams take a dependency on platform capability and roadmap; migration effort from bespoke stacks
- **Risks:** An IDP that lags team needs pushes teams off the paved road; mitigated by product management of the platform, a gap-escalation path, and measuring platform adoption as a health signal rather than mandating around dissatisfaction

## Decision

We will adopt platform engineering as an organizational discipline and Platforma as the internal developer platform for the organization. Deployment to Platforma is exclusively through Nitro per ADR-0005. Platforma is designed and built using domain-driven design per ADR-0003.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** An IDP concentrates expertise once and delivers it through self-service, satisfying both the concentration and self-service drivers without a ticket queue. Golden paths make posture uniform by default. Requiring Nitro as the sole deployment path and structuring Platforma with DDD satisfies architectural coherence: the platform reinforces prior decisions rather than forking them.
- **Why the alternatives lost:** Option 1 was rejected because it duplicates undifferentiated work and produces the posture variance this environment cannot tolerate. Option 2 was rejected because ticket-based centralization converts an expertise problem into a throughput problem and predictably drives shadow infrastructure.
- **Tradeoffs accepted deliberately:** We accept platform dependency in exchange for eliminating per-team infrastructure burden, on the same grounds as ADR-0005: one well-resourced shared dependency over many under-resourced independent ones. We accept that golden paths constrain choice; teams with needs beyond the paved road raise gaps through the escalation path rather than leaving it.
- **Assumptions this rests on:** Assumes Platforma is staffed and managed as a product with a roadmap and service expectations. Assumes Nitro and Platforma integration is a first-class obligation of both platform teams. Assumes the underlying enterprise environment supports the self-service model. If Platforma cannot be resourced as a product, ticket-based centralization is the honest fallback and this ADR should be revised rather than left aspirational.

## Consequences

### Positive

- Application teams spend their capacity on mission capability, not plumbing
- Uniform security, observability, and resilience posture across the fleet
- One stack to onboard against for every new and converged team
- Source-to-runtime is fully governed: Nitro provenance in, Platforma posture out

### Negative

- Platforma is a standing product investment with real staffing cost
- Team flexibility is bounded by the paved road and the gap-escalation process
- Migration effort from inherited bespoke stacks

### Neutral / Follow-on Work

- Define Platforma's initial golden paths and service catalog, structured as bounded contexts per ADR-0003
- Establish the gap-escalation path and platform product management
- Sequence migration from team-managed infrastructure per portfolio
- Publish the joint Nitro-to-Platforma delivery reference: the single paved road from commit to running service

## Conformance and Validation

Workloads run on Platforma; running outside it requires an exception ADR with an expiry date. Platforma accepts deployments only from Nitro; artifacts without Nitro provenance do not deploy. Platform adoption, gap-escalation volume, and time-from-commit-to-running-service are tracked as platform health measures. Architecture reviews verify no shadow infrastructure.

## Notes

The dependency chain this record completes: ADR-0003 defines how capabilities are structured, ADR-0005 defines how software is delivered, and this record defines where it runs. The three together form the paved road; exceptions to any of them are individually documented and time-boxed.
