# ADR-0007: Align on Trenchcoat as the Organizational Design System with Tiered Design Levels

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Experience Design Engineering, Principal Engineers, Portfolio Leads |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0004 (human-centered design; Trenchcoat is its component-level implementation) |

## Context and Problem Statement

The converged organization's applications present users with inconsistent interfaces: different components, interaction patterns, terminology, and visual language per inherited system. Users who work across applications pay a relearning cost at every boundary, teams rebuild the same components repeatedly, and accessibility and usability quality varies with each team's local skill. How do we achieve a consistent, high-quality user experience across the application portfolio without imposing a single uniform investment level on systems with very different user-experience stakes?

If no decision is made, every application continues to hand-roll its interface layer. Component duplication mirrors the service duplication ADR-0003 addresses, experience quality remains a per-team lottery, and the portfolio never reads as one coherent product family.

## Decision Drivers

- Consistent interaction patterns and visual language across applications users move between
- Eliminate duplicated component engineering across teams
- Accessibility, usability, and design quality delivered through the system rather than re-earned per team
- Investment proportional to stakes: a flagship analyst-facing application and an internal back-office utility do not warrant the same design depth
- Coherence with ADR-0004: the design system is how HCD practice reaches the component and pattern level at scale

## Options Considered

### Option 1: Per-team interface development (status quo)

Each team builds its own components and patterns.

- **Pros:** Full team autonomy; no shared dependency
- **Cons:** Duplicated component engineering; inconsistent experience across the portfolio; accessibility and quality vary by team; every design improvement is a fleet-wide retrofit
- **Risks:** High. This is the interface-layer version of the duplication problem already rejected in ADR-0003

### Option 2: Adopt an external design system as-is

Standardize on an existing open design system without organizational adaptation.

- **Pros:** Immediate component availability; documentation and community exist; low initial cost
- **Cons:** Generic systems are not designed for this organization's dense, high-consequence analytical workflows; no organizational identity; no mechanism for domain-specific patterns (map-heavy interfaces, evidence handling, analyst intervention surfaces); customization pressure fragments the system team by team
- **Risks:** The system fits the easy 60 percent and teams fork for the hard 40 percent, recreating fragmentation with extra steps

### Option 3: Trenchcoat, an organizational design system with tiered design levels

Establish Trenchcoat as the design system of record: guidelines, tokens, components, and patterns that teams consume, governed by experience design engineering. Trenchcoat defines design tiers matched to system type, for example: Tier 1 for flagship user-facing applications (full pattern depth, bespoke workflow design, highest accessibility and polish bar), Tier 2 for standard user-facing tools (system components and patterns, standard bar), Tier 3 for back-office and internal utilities (core components and tokens, functional bar). Tier assignment is made per system and recorded.

- **Pros:** One component investment consumed portfolio-wide; consistent experience where users cross applications; quality and accessibility inherited from the system; tiers make investment proportional and explicit rather than uniform or accidental; organizational identity and domain patterns live in one governed place
- **Cons:** Trenchcoat requires standing investment as a product; teams take a dependency on system coverage and roadmap; tier assignment adds a governance decision per system
- **Risks:** System coverage lagging team needs drives forks; mitigated by a contribution model (teams can propose and contribute patterns back), a gap-escalation path, and tier-appropriate flexibility

## Decision

We will align on Trenchcoat as the organizational design system. Trenchcoat establishes the guidelines, design tokens, components, and patterns teams use, with tiered design levels assigned per system based on system type, from flagship user-facing applications to back-office utilities.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** A single governed system delivers consistency, eliminates duplicated component work, and makes quality and accessibility properties of the system rather than per-team achievements. Tiering directly satisfies the proportional-investment driver: it names the reality that different systems warrant different depth, and turns that from an unspoken judgment into a recorded decision. As the component-level carrier of HCD practice, it satisfies coherence with ADR-0004.
- **Why the alternatives lost:** Option 1 was rejected for the same reason its service-layer twin was rejected in ADR-0003: duplication compounds and cross-cutting improvement becomes a fleet retrofit. Option 2 was rejected because generic systems do not carry this domain's patterns, and the predictable per-team customization to close that gap destroys the consistency the system exists to provide.
- **Tradeoffs accepted deliberately:** We accept the standing cost of operating Trenchcoat as a product. We accept constrained interface freedom for teams in exchange for portfolio coherence, with the contribution model as the pressure valve. We accept the governance overhead of tier assignment because implicit, unrecorded investment decisions are how flagship polish ends up on back-office tools and vice versa.
- **Assumptions this rests on:** Assumes experience design engineering is resourced to govern and evolve Trenchcoat. Assumes a contribution model keeps the system fed by team needs rather than governing from a distance. Assumes tier definitions remain stable enough to be meaningful. If system investment cannot be sustained, adopting and adapting an external base under Trenchcoat governance is the fallback to revisit, not per-team fragmentation.

## Consequences

### Positive

- Users move between applications without relearning interaction patterns
- Component engineering happens once and is consumed everywhere
- Accessibility and design quality are inherited, not re-earned
- Design investment per system is explicit, recorded, and proportional to stakes

### Negative

- Standing product investment in Trenchcoat
- Team interface freedom bounded by system coverage and tier
- Migration effort for inherited interfaces built on other foundations

### Neutral / Follow-on Work

- Publish Trenchcoat foundations: principles, tokens, core components, and the tier definitions with assignment criteria
- Record tier assignments for the current application registry
- Establish the contribution model and gap-escalation path
- Sequence interface migration for inherited applications by tier and portfolio priority

## Conformance and Validation

New user-facing development uses Trenchcoat; building outside it requires an exception ADR with an expiry. Each system's tier assignment is recorded and reviewed when system purpose changes. Design reviews validate against the assigned tier's bar, not a uniform bar. Fork detection (local component copies diverging from the system) is a finding in architecture and design reviews.

## Notes

Tier definitions and assignment criteria are owned by experience design engineering and published with Trenchcoat's foundations. The tier list in this record is illustrative of the model; the published definitions are authoritative.
