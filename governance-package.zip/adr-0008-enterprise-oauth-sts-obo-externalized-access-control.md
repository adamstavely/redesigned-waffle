# ADR-0008: Use Enterprise OAuth, STS, and On-Behalf-Of Mechanisms with Access Control Externalized from Applications and Services

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-08-17 |
| **Decision Owner** | Technical Director |
| **Consulted** | Principal Engineers, Security Engineering, Central Engineering, Enterprise identity platform team |
| **Informed** | All engineering teams |
| **Related ADRs** | ADR-0003 (access control as an enterprise capability, not a per-app implementation), ADR-0006 (Platforma golden paths carry the standard auth integration) |

## Context and Problem Statement

Inherited applications and services implement authentication and authorization in divergent ways: local user stores, per-app session schemes, hand-rolled service credentials, and authorization logic embedded in application code. Every variation is an attack surface, an audit burden, and a barrier to composing services, because identity does not flow coherently across system boundaries. How should applications and services authenticate callers and authorize actions, especially in multi-hop call chains where a service acts for a user against other services?

If no decision is made, each new service adds another local implementation of security-critical logic, user identity is lost at service boundaries, and enterprise-level questions ("who can access what, and who did access what") cannot be answered without per-app archaeology.

## Decision Drivers

- Security-critical logic must be implemented by specialists once, not re-implemented per application
- User identity must propagate through multi-hop service chains so downstream services authorize the end user, not a service account with broad standing privileges
- Access decisions must be auditable and administrable at the enterprise level
- Access control changes (policy updates, revocations, new mandates) must not require application code changes
- Coherence with the service layer: capability platforms (ADR-0003) are consumed by many applications and, increasingly, by agents; authorization at that shared surface must be uniform and identity-aware

## Options Considered

### Option 1: Per-application authentication and authorization (status quo)

Each application and service implements its own auth using local stores and embedded logic.

- **Pros:** No external dependency; teams control their own model
- **Cons:** Security-critical code written repeatedly by non-specialists; identity does not cross service boundaries; audit requires per-app effort; every policy change is a code change somewhere; inconsistent posture across the fleet
- **Risks:** High. Divergent auth is among the most exploitable and least auditable forms of fragmentation

### Option 2: Shared authentication with in-app authorization

Adopt enterprise authentication (single sign-on) but leave authorization logic inside each application.

- **Pros:** Solves login consistency; smaller change than full externalization
- **Cons:** Authorization, the harder and more consequential half, remains embedded and divergent; policy is invisible to enterprise administration; service-to-service chains still collapse identity into service accounts; "who can do what" still requires reading application code
- **Risks:** The visible problem (login) is solved while the dangerous one (authorization sprawl) persists behind it

### Option 3: Enterprise OAuth, STS, and on-behalf-of with externalized access control

Standardize on the enterprise identity fabric: OAuth 2.0 flows for user and service authentication, the enterprise Security Token Service for token issuance and exchange, and the on-behalf-of pattern for delegation, so that services in a call chain exchange tokens that carry the end user's identity and act with the user's effective permissions. Authorization decisions are externalized from application code to the enterprise policy layer; applications and services enforce decisions, they do not own them.

- **Pros:** Auth implemented once by the enterprise identity platform and consumed everywhere; user identity flows end to end through OBO token exchange, eliminating broad standing service-account privileges; policy is administered and audited centrally; policy changes deploy without touching application code; the shared service layer gets uniform, identity-aware authorization, which is also the precondition for governed agent access
- **Cons:** Every service takes a dependency on enterprise identity availability; token exchange adds latency per hop; teams must learn the flows; migration from local auth is per-app work
- **Risks:** Enterprise identity becomes a single point of failure for everything; mitigated by treating identity platform availability as a top-tier enterprise obligation with appropriate caching and resilience patterns in the standard integration. Misconfigured OBO chains can over-delegate; mitigated by golden-path integration through Platforma (ADR-0006) rather than hand-built flows

## Decision

We will use the enterprise OAuth, STS, and on-behalf-of authentication and authorization mechanisms for all applications and services, with access control externalized from application and service code to the enterprise identity and policy layer.

## Rationale (Why This Decision)

- **How it satisfies the drivers:** Enterprise mechanisms satisfy implement-once-by-specialists. OBO token exchange satisfies identity propagation: downstream services see and authorize the actual user rather than an omnipotent service account. Externalized policy satisfies central audit and administration, and makes policy change a configuration act rather than a fleet of code changes. Uniform identity-aware authorization at the capability platform surface satisfies coherence with ADR-0003 and prepares that surface for agentic consumers.
- **Why the alternatives lost:** Option 1 was rejected because repeated local implementation of security-critical logic is the highest-risk form of duplication this organization carries. Option 2 was rejected because it solves the cosmetic half of the problem while leaving authorization, where the real exposure lives, fragmented and invisible.
- **Tradeoffs accepted deliberately:** We accept dependency on enterprise identity availability, judging one hardened, monitored dependency safer than many soft local implementations. We accept per-hop token exchange latency as the cost of end-to-end identity. We accept migration effort per inherited application because local auth retired is attack surface retired.
- **Assumptions this rests on:** Assumes the enterprise identity platform (OAuth authorization server, STS, policy administration) is operated to enterprise availability and is accredited for the operating environment. Assumes OBO delegation is supported across the required service topology. Assumes Platforma golden paths carry the reference integration. If the enterprise platform cannot support a required flow, the gap is escalated to the identity platform team; building local auth around the gap requires an exception ADR with an expiry.

## Consequences

### Positive

- Security-critical logic is written once, by specialists, and inherited everywhere
- End-user identity and effective permissions flow through multi-hop service chains
- Enterprise-wide answers to "who can access what" and "who accessed what" become administrable queries
- Policy changes and revocations take effect without application releases
- The shared service layer is uniformly governed and ready for agent access under the same identity model

### Negative

- Universal dependency on enterprise identity availability
- Token exchange latency per service hop
- Per-application migration effort from local auth implementations
- Learning curve for OAuth, STS, and OBO flows across teams

### Neutral / Follow-on Work

- Publish the standard integration patterns: user-facing app flow, service-to-service flow, and OBO delegation chain, as Platforma golden paths
- Inventory inherited local auth implementations and sequence migration per portfolio
- Define the exception process for flows the enterprise platform cannot yet support
- Establish audit reporting from the centralized policy layer

## Conformance and Validation

New applications and services authenticate and authorize exclusively through the enterprise mechanisms; local user stores and embedded authorization logic in new code are findings in architecture and security review. Service-to-service calls acting for a user use OBO token exchange; broad standing service-account privileges are findings. Migration of inherited local auth is tracked per portfolio until retired. Periodic review verifies policy lives in the enterprise layer and not in application code paths.

## Notes

The unifying principle: applications and services are policy enforcement points, never policy decision points. Identity is issued, exchanged, and evaluated by the enterprise fabric; the application's job is to demand a valid token and honor the decision.
