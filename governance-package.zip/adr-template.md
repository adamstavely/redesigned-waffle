# ADR-NNNN: [Short Title of Decision]

| Field | Value |
|---|---|
| **Status** | Proposed / Accepted / Deprecated / Superseded by ADR-NNNN |
| **Date** | YYYY-MM-DD |
| **Decision Owner** | [Name, Role] |
| **Consulted** | [Stakeholders, teams, architecture council] |
| **Informed** | [Teams affected by the outcome] |
| **Related ADRs** | [Links to prior or dependent decisions] |

## Context and Problem Statement

Describe the forces at play: technical constraints, mission or business drivers, organizational factors, and any deadlines. State the problem as a question where possible (e.g., "How should the platform broker credentials for agent sessions?"). Include what happens if no decision is made.

## Decision Drivers

- [Driver 1, e.g., must operate in disconnected or degraded environments]
- [Driver 2, e.g., conformance with enterprise service layer standards]
- [Driver 3, e.g., total cost of ownership over 5 years]
- [Driver 4, e.g., team skill availability and sustainment burden]

## Options Considered

### Option 1: [Name]

Brief description of the approach.

- **Pros:** [What this buys us]
- **Cons:** [What it costs us]
- **Risks:** [What could go wrong, and likelihood]

### Option 2: [Name]

Brief description of the approach.

- **Pros:**
- **Cons:**
- **Risks:**

### Option 3: [Name]

Brief description of the approach.

- **Pros:**
- **Cons:**
- **Risks:**

## Decision

State the chosen option plainly: "We will [decision]." Keep this to one or two sentences. The reasoning lives in the next section.

## Rationale (Why This Decision)

This is the most important section of the record. A future reader should be able to reconstruct the reasoning without talking to anyone who was in the room.

- **How it satisfies the drivers:** Map the chosen option against each decision driver above. Be explicit about which drivers it satisfies fully, partially, or not at all.
- **Why the alternatives lost:** For each rejected option, one or two sentences on the disqualifying factor. "Option 2 was rejected because..." is more durable than silence.
- **Tradeoffs accepted deliberately:** Name what we knowingly gave up and why that was acceptable at the time.
- **Assumptions this rests on:** List the conditions that, if they change, should trigger revisiting this ADR (e.g., "assumes single-region deployment," "assumes vendor X remains FedRAMP authorized").

## Consequences

### Positive

- [Benefit realized]

### Negative

- [Debt incurred, capability foregone, or new constraint accepted]

### Neutral / Follow-on Work

- [New decisions this triggers, migration work, documentation updates]

## Conformance and Validation

How will we know this decision is being followed and is working? (e.g., architecture fitness functions, review gates, metrics, sunset criteria for revisiting the decision.)

## Notes

Links to spikes, prototypes, benchmarks, meeting minutes, or external references that informed the decision.
