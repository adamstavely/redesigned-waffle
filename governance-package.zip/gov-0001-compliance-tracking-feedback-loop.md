# GOV-0001: Compliance Tracking and Feedback Loop

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Owner** | Architecture Council (operated by a designated Governance Steward) |
| **Relates To** | All ADRs and all Technical Directives |
| **Review Cadence** | Annually, and continuously self-measured by its own metrics |

## Purpose

ADRs decide. TDs direct. This document closes the loop: it defines how compliance is tracked, how the directives themselves are measured for health, and how the system revises itself. It is an operating rhythm, not a document type. Its design goal is that governance stays lightweight because it learns, and rules that stay believable need less policing.

## Design Principles

1. **Exception volume is a signal about the rule, not the teams.** A directive generating heavy exception traffic is presumed wrong or premature until shown otherwise.
2. **Revise before enforcing harder.** When a TD is noisy, the first response is to examine the TD.
3. **Automate verification wherever plausible.** Manual review checks are transitional. Every human-checked control carries a stated automation intent or a stated reason none exists.
4. **One register, one review, one appeal path.** No new ceremonies beyond these. Anything this loop cannot absorb in one quarterly review is a sign the rule set is too heavy, which is itself a finding.
5. **Everything the loop decides is recorded in the existing system.** Revisions are ADRs. Directive changes are TD revisions. The loop creates no third record type.

---

## Component 1: The Exception Register

The single authoritative list of every active deviation from any TD.

### Schema

| Field | Description |
|---|---|
| Exception ID | EX-NNNN, sequential |
| Exception ADR | Link to the approving exception ADR |
| TD / ADR deviated from | e.g., TD-0005 / ADR-0005 |
| Owning team and portfolio | Accountable owner |
| Summary | One line: what is being done instead of the rule |
| Grant date | When approved |
| **Expiry date** | Mandatory. No open-ended entries exist |
| Convergence plan status | On track / At risk / Stalled |
| Renewal count | Number of times extended |

### Operating Rules

- An exception is not in effect until it appears in the register. The register is the gate, not the ADR alone.
- Automated expiry alerts fire at T-60, T-30, and T-0 to the owning team, portfolio lead, and Governance Steward.
- At expiry, the exception either closes (converged), renews (a conscious re-approval, incrementing the renewal count), or escalates. Silence is escalation, not extension.
- **Renewal count 2 triggers a mandatory question at the next quarterly review:** is this an exception, or is it evidence the rule is wrong? The answer is recorded either as a convergence commitment with teeth or as a proposed TD/ADR revision.

---

## Component 2: Directive Health Metrics

A small, fixed panel per TD. Deliberately few, so the review reads them in minutes.

| Metric | What it indicates | Collected from |
|---|---|---|
| Active exceptions | Rule friction | Exception Register |
| New exception requests this quarter | Rising friction | Exception Register |
| Gate holds / findings this quarter | Enforcement load | Review records |
| Repeat findings (same team, same TD) | Enablement gap or bad rule | Review records |
| Renewal-count-2 exceptions | Rule likely wrong | Exception Register |
| Verification mode | Automated / Manual / Mixed | Automation Ledger |

### Interpretation Thresholds

These are tripwires for discussion, not automatic verdicts:

- **Healthy:** Few or zero exceptions, findings declining, verification trending automated. Action: none. Do not add process to healthy directives.
- **Friction:** Exception requests rising quarter over quarter, or findings concentrated in specific portfolios. Action: examine whether the gap is enablement (fix with support), platform capability (fix the platform), or the rule (revise the TD).
- **Wrong rule:** Multiple renewal-count-2 exceptions, or exception volume exceeding compliance volume for a given obligation. Action: a revision ADR is drafted for the next review. Enforcement of the contested obligation may be suspended by the Technical Director pending revision.

---

## Component 3: The Quarterly Governance Health Review

One meeting, 90 minutes, quarterly. Chaired by the Technical Director, run by the Governance Steward, attended by the Architecture Council and portfolio leads.

### Fixed Agenda

1. **Exception Register walk (20 min).** Expiring, expired-in-silence, at-risk convergence, and every renewal-count-2 entry. Decisions on each: close, renew, escalate, or refer to revision.
2. **Directive health panel (25 min).** The metrics table for all TDs on one page. Discussion only where thresholds tripped. Healthy directives get zero minutes by design.
3. **Assumption Watch (15 min).** See Component 4. Any ADR assumption reported broken or at risk, and its consequence.
4. **Challenges and revisions (20 min).** Open challenges (Component 5) and revision ADRs in flight. Decisions recorded as ADR status changes.
5. **Automation Ledger progress (10 min).** Manual controls that converted to automated since last quarter, and the next candidates.

### Outputs

- Updated Exception Register decisions
- Revision ADRs commissioned, each with a named author and due date
- A one-page summary published to all engineering teams, so the workforce sees the system correcting itself. This publication is not optional; visible self-correction is what buys legitimacy.

---

## Component 4: Assumption Watch

Every ADR's Rationale section lists the assumptions the decision rests on. This component makes someone responsible for noticing when one breaks.

- The Governance Steward maintains the **Assumption Index**: each material assumption extracted from accepted ADRs, with the trigger condition and the ADR it would reopen.
- Any engineer may flag an assumption as broken or at risk through a lightweight submission (a linked issue referencing the ADR). No form heavier than that.
- Flagged assumptions are triaged by the Steward and land on the quarterly agenda. A confirmed broken assumption obligates a review of the ADR: reaffirm, revise, or supersede. It does not automatically invalidate the decision.

## Component 5: The Challenge Path

Any team may petition to revise or rescind a TD or ADR.

- **Form:** A short written challenge (one page maximum) stating the obligation contested, the evidence of harm or misfit, and the proposed change. Submitted to the Architecture Council via the Governance Steward.
- **Guarantee:** Every challenge receives a decision at the next quarterly review, or sooner if the Technical Director expedites. Decisions are recorded as an ADR (revision, supersession, or a reaffirmation ADR stating why the rule stands).
- **Protection:** Challenging a directive is explicitly legitimate engineering behavior. Compliance is still required while a challenge is pending, unless the Technical Director suspends the contested obligation.
- A rejected challenge with new evidence may be resubmitted. A twice-reaffirmed rule gains a presumption of stability; further challenges require materially new evidence.

## Component 6: The Automation Ledger

The register of how each TD obligation is verified and where it is headed.

| Field | Description |
|---|---|
| TD and statement | e.g., TD-0002 statement 3 |
| Current verification | Automated gate / review checklist / audit / registry |
| Automation target | The intended machine check, or "none plausible" with reason |
| Owner and target quarter | Who converts it, by when |

Priority order for conversion: obligations with the highest quarterly finding counts first, since those consume the most human review attention. The strategic direction is that Nitro, Platforma, and the repository platform become the enforcement fabric: provenance checks, deployment rejections, linting of ADR and diagram presence, credential issuance policy, and component-fork detection all live in the pipeline and platform rather than in meetings.

---

## Roles

| Role | Responsibility |
|---|---|
| **Technical Director** | Chairs the review; approves revisions, suspensions, and expedited challenges |
| **Governance Steward** | Operates the registers, alerts, index, and agenda. This is a rotating assignment among principal engineers, deliberately, so the system's operating burden is felt by those with authority to lighten it |
| **Architecture Council** | Decides challenges, reviews revision ADRs, adjudicates renewal-count-2 exceptions |
| **Portfolio leads** | Answer for their portfolios' exceptions and convergence plans |
| **Any engineer** | May flag assumptions and submit challenges |

## The Loop's Own Health

This system measures itself by the same standard it applies:

- Quarterly review consistently exceeding 90 minutes means the rule set or the registers are too heavy. That is a finding against the governance system, addressed by simplification, not by lengthening the meeting.
- A quarter with zero revisions, zero challenges, and zero assumption flags is examined skeptically: either the rules are perfect or the feedback channels have gone quiet. The Steward samples for the latter.
- Governance overhead per team (hours spent on compliance activity) may be spot-sampled annually. Rising overhead against stable directive count is a simplification trigger.

## Notes

The three-part system in one sentence each: ADRs record what we decided and why. Technical Directives state what is therefore required. This loop watches whether the requirements are working, expires what should not persist, and revises what the evidence says is wrong.

**Document interaction model:**

| Layer | Function | Mutability | Generated when |
|---|---|---|---|
| ADR | Records a decision and its rationale | Immutable; superseded, never edited | Every architecturally significant decision |
| TD | States enforceable obligations implementing an ADR | Versioned and revisable | Only when an ADR binds cross-team behavior requiring enforcement |
| STD | Specifies how work products are made; bound by reference from TDs | Living document, owner-maintained under change control | Only when a TD binds detailed specification better maintained by a domain owner |
| GOV | Defines how the governance machinery operates | Living document | Only for operating mechanisms of the system itself |

In brief: ADR decides, TD obliges, STD specifies, GOV operates.

Not every ADR results in a TD; most do not. Every TD, STD, and GOV traces to an implementing or establishing ADR. ADRs are the root of the graph. Exceptions to any TD are themselves ADRs, so the entire system, including its deviations, is navigable from the ADR index. STD carries a materiality guardrail: owners edit freely, but changes that expand obligations are flagged to the Council or the quarterly review before taking effect, since a TD binding "the current published standard" delegates rule-writing to the standard's owner.
