# How We Govern Our Architecture: The Operating Model

*A plain-language overview of our technical governance system, for every engineer in the organization.*

## The Whole System in Four Sentences

**ADRs decide.** When we make a significant architecture decision, we write down what we chose and why, so the reasoning outlives the meeting.

**TDs oblige.** When a decision requires teams to do something (or stop doing something), a Technical Directive states that obligation clearly and testably.

**STDs specify.** When an obligation depends on detailed craft (how to draw a diagram, what makes a service "productized"), that detail lives in a standard maintained by the people closest to the craft.

**GOVs operate.** A small set of living documents keeps the machinery itself running: the registers, the review rhythm, and the rules for changing the rules.

That's the entire vocabulary. Four prefixes, four jobs.

## How They Connect

```mermaid
graph TD
    ADR["ADR: the decision and its rationale<br/>(immutable record)"]
    TD["TD: the obligation<br/>(what teams must do)"]
    STD["STD: the specification<br/>(how the work is done)"]
    GOV["GOV: the machinery<br/>(registers, reviews, feedback)"]
    EX["Exception<br/>(also an ADR, with an expiry date)"]

    ADR -->|"only when enforcement is needed"| TD
    TD -->|"binds by reference"| STD
    ADR -.->|"establishes"| GOV
    TD -->|"deviation requires"| EX
    GOV -->|"tracks, measures, and revises"| TD
    GOV -->|"watches assumptions of"| ADR
```

Everything traces back to an ADR. Every directive implements one. Every standard and every piece of governance machinery was established by one. Even exceptions are ADRs, so the whole system, including its deviations, is one navigable graph with decisions at the root.

## What This Actually Asks of You

Here is the honest day-to-day footprint, because a governance system that reads like a legal code gets ignored, and this one is built not to.

**Most days: nothing.** If you're building features inside an existing architecture, using the golden paths, and consuming the platforms, the system is invisible. You're already compliant by default, because the paved road was built to be the easy road.

**When you make a significant architecture decision: write an ADR.** One document, one template, mostly the thinking you already did, written down. The test for "significant" is simple: will someone two years from now need to know why? If yes, record it. If it's a local implementation choice, don't.

**When you propose a new service: check the context map first.** If the capability already exists as a platform, consume it. That check takes minutes and saves months.

**When a rule doesn't fit your situation: request an exception.** This is a first-class, legitimate move, not a workaround. Write a short exception ADR, get it approved, give it an expiry date. You are not fighting the system; you are using it.

**When you think a rule is wrong: challenge it.** One page, to the Architecture Council. You are guaranteed a decision by the next quarterly review. Challenging a directive is explicitly legitimate engineering behavior, and a rule that survives challenges gets stronger, not just older.

That's the complete list. Nobody outside the governance roles reads registers, attends extra meetings, or fills out compliance paperwork.

## Why It Stays Lightweight

The system was designed with specific mechanisms to keep itself small. These aren't aspirations; they're built in.

**Most decisions never generate a directive.** A TD exists only when a decision binds cross-team behavior and violations would be invisible without a check. The founding set is eight directives. The count grows slowly by design, because the bar for creating one is deliberately high.

**Healthy rules get zero attention.** The quarterly review spends time only where the metrics show friction. A directive nobody struggles with consumes no minutes, generates no paperwork, and asks nothing further of anyone.

**Enforcement is moving into the platform, not into meetings.** Provenance checks, deployment gates, and credential policy live in Nitro and Platforma, where compliance is automatic and invisible. Every manual review check carries a stated plan to become an automated one. The end state is that doing the right thing requires no thought and doing the wrong thing is simply not possible, which is the lightest governance there is.

**Exception volume changes the rule, not the enforcement.** If a directive generates heavy exception traffic, the system's first assumption is that the rule is wrong, not that teams are misbehaving. An exception renewed twice forces the question at review: fix the convergence, or fix the rule.

**The system measures its own weight.** A quarterly review that runs long is a finding against the governance system, answered by simplification. Governance overhead per team is sampled, and rising overhead against a stable rule count triggers a diet, not a bigger meeting.

**Detail is delegated to the people who own the craft.** Standards are maintained by their domain owners and updated freely, without directive-level ceremony, with one guardrail: changes that expand what's required of teams get flagged before taking effect. The rules stay current because updating them is easy for the people who know best.

## A Decision's Life, End to End

A team decides their application needs full-text search. They check the context map: search is a capability platform. They consume it through its published contract. No documents created, no reviews triggered. This is the common case, and it's the whole story.

A platform team decides to change a bounded context boundary. That's significant: they write an ADR with the rationale, the Council reviews it because it's cross-cutting, and the context map is updated. No TD is created, because the existing directive (consume from the map) already covers enforcement. One document.

A team needs to run a workload Platforma can't support yet. They file the gap with the platform team and write a short exception ADR with a six-month expiry. It lands in the Exception Register. If the gap closes, they converge. If they're still renewing the exception a year later, the quarterly review asks whether Platforma has a roadmap problem, and the evidence is already organized to answer it.

Notice what never happened in any of these: a form for its own sake, a meeting without a decision, or a document nobody will read.

## Where Everything Lives

The templates (`adr-template`, `td-template`, `std-template`), the founding records (ADR-0001 through 0008, TD-0001 through 0008), and the machinery (GOV-0001) are in the governance repository, with the ADR index as the front door. Start with the index; everything else is one link away.

If you take one thing from this page, take the four-sentence version at the top. The rest is detail you can look up the day you need it.

Build well.
