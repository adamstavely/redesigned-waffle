# STD-NNNN: [Name of Standard]

| Field | Value |
|---|---|
| **Status** | Draft / Published / Deprecated / Superseded by STD-NNNN |
| **Version** | X.Y (increment Y for clarifying changes, X for material changes) |
| **Owner** | [Named team or role accountable for content] |
| **Bound By** | [TDs that reference this standard, e.g., TD-0002] |
| **Established By** | [The ADR whose decision this standard specifies] |
| **Last Changed** | YYYY-MM-DD |

## Scope

One paragraph: what this standard specifies and what work products it applies to. Obligations to comply live in the binding TD, not here; this document defines the "how" the TD points at.

## Specification

[The content of the standard: rules, definitions, templates, examples, criteria. Structure freely as the subject demands. This is the only substantial section and it belongs to the owner.]

## Change Control

- The owner may make editorial and clarifying changes freely (version Y increment, change note below).
- Changes that materially expand obligations on teams (new mandatory items, raised bars, new required elements) require flagging to the Architecture Council or the Quarterly Governance Health Review before taking effect (version X increment).
- The binding TD is not revised for standard changes; it binds to the current published version by design.

## Change Note

| Date | Version | Change | Material (Y/N) |
|---|---|---|---|
| YYYY-MM-DD | 1.0 | Initial publication | N/A |
