# TD-0001: Architecture Decision Records Are Mandatory for Architecturally Significant Decisions

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0001: Adopt Architecture Decision Records for All Architecture Decisions |
| **Applies To** | All engineering teams, all portfolios |
| **Review Cadence** | Annually, or upon change to ADR-0001 |

## Purpose

This directive makes the ADR practice established in ADR-0001 an enforceable obligation. Rationale for the practice is recorded in ADR-0001.

## Directive Statements

1. Teams SHALL record every architecturally significant decision as an ADR using the standard organizational template before or concurrent with implementing the decision.
2. ADRs SHALL be stored in version control in the designated ADR location for the owning system or portfolio and SHALL be registered in the organizational ADR index.
3. ADRs SHALL include a completed Rationale section; ADRs with empty or placeholder rationale SHALL be returned in review.
4. Accepted ADRs SHALL NOT be edited to change their substance; changes of direction SHALL be recorded as a new ADR that supersedes the prior record.
5. Pull requests implementing significant architectural change SHALL reference the governing ADR.
6. Cross-cutting ADRs (affecting more than one portfolio or any capability platform) SHALL be reviewed by the Architecture Council before acceptance.

## Applicability and Effective Scope

- **New work:** All statements apply immediately to decisions made on or after the effective date.
- **Existing systems:** Backfill of legacy decisions is encouraged, not mandated; however, any change to a legacy architecture on or after the effective date SHALL be recorded as an ADR.
- **Out of scope:** Implementation-level choices with no architectural consequence (naming, local refactoring, routine dependency updates).

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1 through 6 in force for new decisions | 2026-08-17 |
| Phase 1 | All teams onboarded to the template and index; ADR locations designated per portfolio | +30 days |
| Full compliance | Architecture reviews enforce ADR references without grace | +60 days |

## Verification

Architecture reviews and pull request review check for governing ADR references. The Architecture Council samples ADRs quarterly for rationale quality. The ADR index is audited for completeness against known significant changes.

## Exceptions

None anticipated; a decision too urgent to document is documented immediately after execution, not exempted. Any claimed exception requires Technical Director approval.

## Non-Compliance

Significant architectural change without an ADR is a review finding. The change is not approved until the ADR exists. Repeat findings escalate to the portfolio lead and Architecture Council.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
