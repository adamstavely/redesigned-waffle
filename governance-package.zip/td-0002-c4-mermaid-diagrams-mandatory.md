# TD-0002: Architecture Diagrams Use the C4 Model in Mermaid and Accompany Structure-Changing ADRs

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0002: Use the C4 Model with Mermaid to Diagram Architecture and Associate Diagrams with ADRs |
| **Applies To** | All engineering teams, all portfolios |
| **Review Cadence** | Annually, or upon change to ADR-0002 or the C4 Architecture Diagram Standard |

## Purpose

This directive enforces the diagramming standard established in ADR-0002 and the C4 Architecture Diagram Standard.

## Directive Statements

1. Architecture diagrams SHALL use the C4 model and SHALL be authored in Mermaid.
2. Every ADR that changes system structure SHALL include or reference the affected C4 diagrams, showing to-be state and, where structure is being changed rather than created, as-was state.
3. Mermaid source SHALL be committed to version control; rendered images MAY be exported but SHALL NOT be the source of record.
4. Diagrams SHALL follow the notation rules of the C4 Architecture Diagram Standard: title stating the C4 level, full element labels, and one concern per diagram.
5. Each system's owning team SHALL maintain a canonical diagram set in the system's repository, updated when accepted ADRs change structure.
6. Teams SHALL NOT introduce alternative diagram languages or freeform diagram tools as the source of record for architecture.

## Applicability and Effective Scope

- **New work:** All statements apply immediately.
- **Existing systems:** Canonical diagram sets SHALL be established per the timeline below; conversion of legacy diagrams is required only for systems undergoing active architectural change.
- **Out of scope:** Non-architectural diagrams (sequence sketches in tickets, whiteboard captures) provided they are not presented as architecture of record.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1 through 4 and 6 in force | 2026-08-17 |
| Phase 1 | Canonical diagram sets established for all Tier 1 and actively changing systems | +60 days |
| Full compliance | Canonical diagram sets established for all systems in the application registry | +120 days |

## Verification

ADR review applies the pre-review checklist from the C4 standard: Mermaid source committed, level stated in title, image is export not source. Architecture reviews sample canonical diagram sets against deployed reality; drift is a finding.

## Exceptions

Deviations require an exception ADR referencing this directive and ADR-0002, approved by the Architecture Council, with expiry and remediation plan.

## Non-Compliance

Structure-changing ADRs without required diagrams are returned in review and not accepted. Diagram drift findings carry a remediation date tracked by the owning team's portfolio.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
