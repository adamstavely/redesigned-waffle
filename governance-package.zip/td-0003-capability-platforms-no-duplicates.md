# TD-0003: Shared Capabilities Are Consumed from Capability Platforms; Duplicate Services Are Prohibited

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0003: Use Domain-Driven Design to Build Capability Platforms as the Integrated Service Layer for All Applications |
| **Applies To** | All engineering teams, all portfolios, all capability platform teams |
| **Review Cadence** | Annually, or upon change to ADR-0003 or the context map |

## Purpose

This directive enforces the capability platform model established in ADR-0003: one implementation per business capability, consumed by all applications through published contracts.

## Directive Statements

1. Applications SHALL consume shared capabilities from the capability platform layer through published contracts and SHALL NOT build local implementations of capabilities present in the context map.
2. Proposals for new services SHALL be checked against the context map before build; a capability already owned by a platform SHALL be requested from that platform, not reimplemented.
3. Capability platform boundaries SHALL be defined as DDD bounded contexts and SHALL be recorded in the organizational context map, which is the authoritative register of capability ownership.
4. Changes to bounded context boundaries SHALL be recorded as ADRs referencing ADR-0003 and reviewed by the Architecture Council.
5. Capability platforms SHALL meet the productization standard (published contract, versioning policy, consumer onboarding, service expectations) before consumers integrate.
6. Gaps in platform capability SHALL be raised through the platform's escalation path; teams SHALL NOT build around a gap without an approved exception ADR.

## Applicability and Effective Scope

- **New work:** All statements apply immediately to new services and applications.
- **Existing systems:** Inherited duplicate services SHALL be registered in the rationalization backlog; migration follows the portfolio sequencing plan. Continued operation of a known duplicate is permitted only while its rationalization entry is active and on schedule.
- **Out of scope:** Application-internal logic that is genuinely app-specific and not a shared business capability.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1, 2, 4, 6 in force | 2026-08-17 |
| Phase 1 | Initial context map published; duplicate service inventory complete | +60 days |
| Phase 2 | Rationalization sequencing approved per portfolio | +120 days |
| Full compliance | Duplicates migrated or covered by active exception ADRs | Per portfolio plan |

## Verification

Architecture review of new services includes a context map check. The context map and rationalization backlog are reviewed quarterly by the Architecture Council. Platform conformance to the productization standard is assessed before consumer onboarding.

## Exceptions

Building a capability that duplicates the platform layer requires an exception ADR referencing this directive and ADR-0003, approved by the Architecture Council, with expiry and a convergence plan back to the platform.

## Non-Compliance

Undeclared duplicate services discovered in review are findings with mandatory rationalization entries. New builds that bypassed the context map check are held at review until resolved.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
