# TD-0004: User Validation Evidence Is Required at Delivery Gates

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0004: Use Human-Centered Design and Development Practices Across All Product Work |
| **Applies To** | All product-building teams; experience design engineering |
| **Review Cadence** | Annually, or upon change to ADR-0004 or the HCD practice guide |

## Purpose

This directive converts the HCD practice established in ADR-0004 into gate obligations. The test it enforces: every significant build decision can answer which user, doing what work, validated that it helps.

## Directive Statements

1. Teams SHALL produce user research and workflow understanding artifacts before build commitment for new products and major features, per the HCD practice guide.
2. Teams SHALL validate designs with representative users (or approved proxy users where direct access is constrained) during build, and SHALL record findings.
3. Releases of user-facing capability SHALL include usability validation evidence appropriate to the system's Trenchcoat tier (TD-0007).
4. Where proxy users or operational SMEs substitute for end users, the substitution SHALL be recorded as such and treated as weaker evidence, not equivalent evidence.
5. Feature proposals SHALL state the user need and validation basis; proposals that cannot SHALL NOT proceed to build commitment.
6. Experience design engineering SHALL embed design support in delivery teams per portfolio allocation and SHALL maintain the HCD practice guide and gate criteria.

## Applicability and Effective Scope

- **New work:** All statements apply to products and major features entering discovery or build after the effective date.
- **Existing systems:** In-flight work completes under current plans; the next major feature or release cycle enters under this directive.
- **Out of scope:** Non-user-facing infrastructure and platform internals, except where they materially change a user-facing workflow.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 4 and 5 in force | 2026-08-17 |
| Phase 1 | HCD practice guide and gate criteria published; enablement scheduled | +45 days |
| Full compliance | All gates enforced across portfolios | +90 days |

## Verification

Delivery reviews check phase-appropriate evidence: research artifacts at build commitment, validation findings at release. Experience design engineering audits evidence quality by sample. Adoption and workaround signals are reviewed per product as trailing indicators.

## Exceptions

Time-critical operational deliveries MAY release with deferred validation only with portfolio lead approval and a scheduled validation date; the deferral is recorded and tracked to closure.

## Non-Compliance

Missing validation evidence at a gate holds the gate. Repeated gate holds in a team trigger an enablement engagement with experience design engineering rather than punitive escalation on first occurrence; persistent non-compliance escalates to the portfolio lead.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
