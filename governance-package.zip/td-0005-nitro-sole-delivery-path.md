# TD-0005: Nitro Is the Sole Build, Delivery, and Deployment Path

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0005: Use the Enterprise CI/CD Pipeline (Nitro) for All Software Build, Delivery, and Deployment |
| **Applies To** | All engineering teams; Nitro platform team; environment owners |
| **Review Cadence** | Annually, or upon change to ADR-0005 |

## Purpose

This directive enforces Nitro as the single path from source to production established in ADR-0005.

## Directive Statements

1. All software SHALL be built, delivered, and deployed through Nitro.
2. Production deployment credentials SHALL be issued only to Nitro; teams and individuals SHALL NOT hold direct production deployment credentials.
3. Artifacts without Nitro provenance SHALL NOT be deployable to any managed environment, including Platforma (TD-0006).
4. Teams SHALL NOT operate shadow pipelines; any build or deployment tooling outside Nitro discovered in use SHALL be registered and scheduled for decommission.
5. Nitro capability gaps SHALL be raised through the Nitro gap-escalation path; building around a gap requires an approved exception ADR.
6. Inherited pipelines SHALL be migrated per the portfolio migration sequence and decommissioned at migration completion.

## Applicability and Effective Scope

- **New work:** Statements 1 through 5 apply immediately to all new services and repositories.
- **Existing systems:** Inherited pipelines operate only within the approved migration sequence; each carries a decommission date.
- **Out of scope:** Local developer builds on workstations for development purposes, provided no artifact from them reaches a managed environment.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1 through 5 for new work; credential restriction begins | 2026-08-17 |
| Phase 1 | Inherited pipeline inventory and migration sequence approved per portfolio | +45 days |
| Full compliance | All inherited pipelines migrated and decommissioned | Per portfolio plan |

## Verification

Provenance verification at deployment: managed environments reject artifacts without Nitro attestation. Credential audits confirm no direct production deployment access outside Nitro. Architecture reviews check for shadow pipelines. Migration progress is tracked per portfolio.

## Exceptions

Deviations require an exception ADR referencing this directive and ADR-0005, approved by the Technical Director, with expiry and a convergence plan to Nitro.

## Non-Compliance

Shadow pipelines are findings with mandatory registration and decommission dates. Artifacts deployed without provenance are treated as deployment incidents, not merely review findings.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
