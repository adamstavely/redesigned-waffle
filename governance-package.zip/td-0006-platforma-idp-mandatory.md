# TD-0006: Workloads Run on Platforma; Deployment to Platforma Is via Nitro Only

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0006: Adopt Platform Engineering with Platforma as the Internal Developer Platform |
| **Applies To** | All engineering teams; Platforma platform team; Nitro platform team |
| **Review Cadence** | Annually, or upon change to ADR-0006 |

## Purpose

This directive enforces Platforma as the organizational internal developer platform established in ADR-0006, and binds its deployment path to Nitro per ADR-0005.

## Directive Statements

1. Organizational workloads SHALL run on Platforma; running outside Platforma requires an approved exception ADR with an expiry date.
2. Platforma SHALL accept deployments exclusively from Nitro; artifacts without Nitro provenance SHALL NOT deploy to Platforma (TD-0005).
3. Teams SHALL use Platforma golden paths for provisioning, runtime configuration, observability, and secrets handling; hand-built alternatives to a golden path SHALL NOT be introduced where a golden path exists.
4. Platforma capability gaps SHALL be raised through the platform gap-escalation path; building around a gap requires an approved exception ADR.
5. Platforma's internal capabilities SHALL be structured as bounded contexts behind published contracts per ADR-0003, and Platforma SHALL meet the productization standard.
6. The Platforma team SHALL publish and maintain platform service expectations, the golden path catalog, and the joint Nitro-to-Platforma delivery reference.
7. Migration from team-managed infrastructure SHALL follow the portfolio sequencing plan, with each bespoke stack carrying a decommission date.

## Applicability and Effective Scope

- **New work:** Statements 1 through 5 apply immediately to new services.
- **Existing systems:** Inherited infrastructure operates only within the approved migration sequence.
- **Out of scope:** Workload classes Platforma does not yet support, provided they are registered as platform gaps with escalation entries, not silently excluded.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1 through 5 for new work | 2026-08-17 |
| Phase 1 | Golden path catalog and service expectations published; migration sequence approved | +60 days |
| Full compliance | Inherited infrastructure migrated or covered by active exception ADRs | Per portfolio plan |

## Verification

Environment inventory reconciles running workloads against Platforma; unregistered workloads outside Platforma are findings. Deployment-time provenance checks enforce statement 2. Platform health measures (adoption, gap-escalation volume, commit-to-running time) are reviewed quarterly.

## Exceptions

Running outside Platforma or bypassing a golden path requires an exception ADR referencing this directive and ADR-0006, approved by the Technical Director, with expiry and a convergence plan.

## Non-Compliance

Shadow infrastructure is a finding with mandatory registration and a remediation date. Deployment attempts without Nitro provenance are rejected at the platform boundary and logged as incidents.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
