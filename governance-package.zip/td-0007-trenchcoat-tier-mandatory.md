# TD-0007: User-Facing Development Uses Trenchcoat at the System's Assigned Design Tier

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0007: Align on Trenchcoat as the Organizational Design System with Tiered Design Levels |
| **Applies To** | All teams building user-facing capability; experience design engineering |
| **Review Cadence** | Annually, or upon change to ADR-0007 or Trenchcoat tier definitions |

## Purpose

This directive enforces Trenchcoat as the design system of record established in ADR-0007, including tier assignment and tier-appropriate review.

## Directive Statements

1. User-facing development SHALL use Trenchcoat guidelines, tokens, components, and patterns; building interface foundations outside Trenchcoat requires an approved exception ADR.
2. Every system with a user interface SHALL have a recorded Trenchcoat tier assignment before build commitment; the tier register is maintained by experience design engineering.
3. Design reviews SHALL validate against the assigned tier's bar, not a uniform bar; tier assignments SHALL be revisited when a system's purpose or audience materially changes.
4. Teams SHALL NOT maintain locally diverged copies of Trenchcoat components; needed changes SHALL be proposed through the contribution model or raised as system gaps.
5. Trenchcoat gaps SHALL be raised through the gap-escalation path; interim local implementations require a registered gap entry and SHALL converge to the system when the gap closes.
6. Experience design engineering SHALL publish and maintain Trenchcoat foundations, tier definitions and assignment criteria, the contribution model, and the gap-escalation path.

## Applicability and Effective Scope

- **New work:** Statements 1 through 5 apply immediately to new user-facing development.
- **Existing systems:** Inherited interfaces migrate per the tier-prioritized sequencing plan; Tier 1 systems migrate first.
- **Out of scope:** Systems with no user interface; third-party COTS interfaces the organization does not build.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1, 4, 5 in force for new work | 2026-08-17 |
| Phase 1 | Trenchcoat foundations and tier definitions published; tier register populated for the application registry | +60 days |
| Phase 2 | Migration sequencing approved per portfolio, Tier 1 first | +120 days |
| Full compliance | Inherited interfaces migrated or covered by active exception ADRs | Per portfolio plan |

## Verification

Design reviews check Trenchcoat usage and validate against the assigned tier. Fork detection (diverged local component copies) is checked in architecture and design reviews. The tier register is audited against the application registry for completeness.

## Exceptions

Building outside Trenchcoat requires an exception ADR referencing this directive and ADR-0007, approved by experience design engineering and the Technical Director, with expiry and a convergence plan.

## Non-Compliance

Unassigned tiers hold build commitment. Component forks are findings with convergence dates. Interfaces built outside the system without exception coverage are findings escalated to the portfolio lead.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
