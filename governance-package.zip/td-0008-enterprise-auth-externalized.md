# TD-0008: Authentication and Authorization Use Enterprise OAuth, STS, and OBO; Access Control Is Externalized

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-0008: Use Enterprise OAuth, STS, and On-Behalf-Of Mechanisms with Access Control Externalized from Applications and Services |
| **Applies To** | All applications and services; security engineering; enterprise identity platform team |
| **Review Cadence** | Annually, or upon change to ADR-0008 or enterprise identity platform capability |

## Purpose

This directive enforces the identity model established in ADR-0008: applications and services are policy enforcement points, never policy decision points.

## Directive Statements

1. Applications and services SHALL authenticate users and callers exclusively through the enterprise OAuth mechanisms and SHALL NOT implement local user stores or local credential schemes.
2. Service-to-service calls acting on behalf of a user SHALL use STS token exchange with the on-behalf-of pattern so that downstream services receive and authorize the end user's identity.
3. Services SHALL NOT rely on broad standing service-account privileges where OBO delegation is available for the flow.
4. Authorization decisions SHALL be externalized to the enterprise policy layer; applications and services SHALL enforce decisions and SHALL NOT embed authorization policy in application code.
5. Auth integration SHALL follow the published Platforma golden paths (TD-0006) for the applicable flow: user-facing, service-to-service, or OBO delegation chain.
6. Flows the enterprise identity platform cannot support SHALL be escalated to the identity platform team; local auth built around a gap requires an approved exception ADR with an expiry.
7. Inherited local auth implementations SHALL be registered in the migration inventory and retired per the portfolio sequencing plan.

## Applicability and Effective Scope

- **New work:** Statements 1 through 6 apply immediately to all new applications and services.
- **Existing systems:** Inherited local auth operates only within the approved migration sequence, each entry carrying a retirement date.
- **Out of scope:** None. Every application and service that authenticates or authorizes is in scope.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | Statements 1 through 6 for new work | 2026-08-17 |
| Phase 1 | Golden path integration patterns published; local auth inventory complete | +60 days |
| Phase 2 | Migration sequencing approved per portfolio | +120 days |
| Full compliance | Local auth retired or covered by active exception ADRs | Per portfolio plan |

## Verification

Security and architecture reviews check for local user stores, embedded authorization logic, and standing service-account usage where OBO applies; each is a finding. Centralized policy layer audit reporting answers who-can-access and who-did-access at the enterprise level. Migration inventory progress is tracked per portfolio to retirement.

## Exceptions

Deviations require an exception ADR referencing this directive and ADR-0008, approved by security engineering and the Technical Director, with expiry and a convergence plan to the enterprise mechanisms.

## Non-Compliance

New code introducing local auth or embedded authorization policy is held at review until remediated. Discovered standing-privilege service accounts in OBO-capable flows are security findings with remediation dates. Unregistered inherited local auth discovered after the inventory deadline is a finding escalated to the portfolio lead and security engineering.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance | Technical Director |
