# TD-NNNN: [Short Title of Directive]

| Field | Value |
|---|---|
| **Status** | Draft / In Effect / Rescinded / Superseded by TD-NNNN |
| **Effective Date** | YYYY-MM-DD |
| **Issuing Authority** | Technical Director |
| **Implements** | ADR-NNNN: [Title] |
| **Applies To** | [Portfolios, teams, system classes in scope] |
| **Review Cadence** | [e.g., Annually, or upon change to the implementing ADR] |

## Purpose

One paragraph. What this directive requires and why it exists. Rationale lives in the implementing ADR; this document states obligations. Reference the ADR rather than restating its reasoning.

## Directive Statements

Numbered, testable obligations using SHALL / SHALL NOT / MAY per RFC 2119. Each statement should be verifiable by inspection, tooling, or review. One obligation per statement.

1. [Teams SHALL ...]
2. [Systems SHALL NOT ...]
3. [Teams MAY ... provided that ...]

## Applicability and Effective Scope

- **New work:** Obligations that apply immediately to new systems, services, or changes.
- **Existing systems:** Obligations that apply to inherited or in-flight work, and the migration expectation.
- **Out of scope:** Anything explicitly excluded, and why.

## Compliance Timeline

| Milestone | Requirement | Date |
|---|---|---|
| Immediate | [What applies on the effective date] | YYYY-MM-DD |
| Phase 1 | [First migration milestone] | YYYY-MM-DD |
| Full compliance | [End state] | YYYY-MM-DD |

## Verification

How compliance is checked: automated gates, review checklists, audits, registries, or metrics. Name the mechanism and the responsible party. Prefer verification that is continuous and automated over periodic and manual.

## Exceptions

Deviations require an exception ADR referencing this directive and the implementing ADR, approved by [approval authority], with a stated expiry date and a remediation plan. Exceptions without expiry dates are not granted.

## Non-Compliance

What happens when a violation is found: finding severity, remediation expectations, escalation path, and any gating consequences (e.g., release hold, review escalation to the Architecture Council).

## Revision History

| Date | Change | Author |
|---|---|---|
| YYYY-MM-DD | Initial issuance | [Name] |
