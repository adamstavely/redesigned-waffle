# GOV-0003: Exception Register

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Established By** | ADR-0001 (exception-as-ADR pattern) as operationalized by GOV-0001 |
| **Owner** | Governance Steward |
| **Kind** | Register |
| **Review Cadence** | Walked in full at every Quarterly Governance Health Review |

## Purpose

The single authoritative list of every active deviation from any Technical Directive. Per GOV-0001: an exception is not in effect until it appears here. The register is the gate, not the approving ADR alone. This document holds the live entries; the rules governing them are defined in GOV-0001 Component 1 and restated operationally below.

## Schema

| Field | Meaning |
|---|---|
| Exception ID | EX-NNNN, sequential, never reused |
| Exception ADR | Link to the approving ADR (also indexed in GOV-0002 as Type: Exception) |
| Deviates From | TD-NNNN / ADR-NNNN |
| Owner | Team and portfolio accountable |
| Summary | One line: what is being done instead of the rule |
| Granted | Approval date |
| Expires | Mandatory; no open-ended entries exist |
| Convergence | On track / At risk / Stalled |
| Renewals | Count of extensions; 2 triggers the mandatory review question |

## The Register

| Exception ID | Exception ADR | Deviates From | Owner | Summary | Granted | Expires | Convergence | Renewals |
|---|---|---|---|---|---|---|---|---|
| *(no active exceptions)* | | | | | | | | |

## Operating Rules

1. Entry occurs when the exception ADR is accepted; the approving authority's sign-off is not complete until the entry exists.
2. Automated expiry alerts fire at T-60, T-30, and T-0 to the owning team, portfolio lead, and Steward.
3. At expiry: close (converged), renew (conscious re-approval, renewal count incremented), or escalate. **Silence is escalation, not extension.**
4. Renewals reaching 2 place the entry on the next quarterly agenda with the mandatory question: is this an exception, or evidence the rule is wrong? The answer is recorded as either a convergence commitment or a proposed TD/ADR revision.
5. Closed entries move to the archive section below with their outcome, preserving the history of where the rules bent.

## Archive

| Exception ID | Deviates From | Outcome | Closed |
|---|---|---|---|
| *(none yet)* | | | |

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Governance Steward | Maintains entries, operates alerts, prepares the quarterly walk |
| Owning teams | Keep convergence status current; respond to expiry alerts |
| Portfolio leads | Answer for their portfolios' entries at review |
| Architecture Council | Adjudicates renewal-count-2 entries |

## Change Discipline

- **Keeping it true:** entry lifecycle updates are direct edits by the Steward.
- **Changing how the machinery works:** rule changes (alert thresholds, the renewal-count trigger, expiry semantics) require an ADR revising GOV-0001's design.

## Health

Register size and its trend are themselves primary directive-health signals consumed by GOV-0001. Register-specific health: no entry lacking an expiry date (hard rule), no At risk/Stalled entry older than one review cycle without a decision, alert delivery verified quarterly.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance, empty register | Technical Director |
