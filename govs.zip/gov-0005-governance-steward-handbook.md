# GOV-0005: Governance Steward Handbook

| Field | Value |
|---|---|
| **Status** | Draft (activates at first rotation handoff; see Notes) |
| **Effective Date** | At first handoff |
| **Established By** | GOV-0001 (Steward role definition) |
| **Owner** | Current Governance Steward |
| **Kind** | Operating Procedure |
| **Review Cadence** | Rewritten as needed at each handoff; the outgoing Steward's exit obligation |

## Purpose

Everything the incoming Governance Steward needs to operate the machinery without oral tradition. The role rotates among principal engineers deliberately, so the operating burden is felt by people with authority to lighten it; this handbook is what makes the rotation survivable.

## The Role in One Paragraph

The Steward operates; the Steward does not decide. You maintain the registers, run the alerts, build the quarterly agenda, triage assumption flags, and route challenges. Decisions belong to the Council and the Technical Director. Your unique authority is the one GOV-0001 grants the operator: when the machinery is too heavy, you are the first to feel it and the one expected to propose the simplification.

## Recurring Duties

**Weekly (target: under 30 minutes)**
1. Scan the Exception Register (GOV-0003) for alerts fired and responses owed; nudge silent owners once before treating silence as escalation.
2. Triage any new assumption flags and challenge submissions; acknowledge receipt.

**Monthly (target: under 1 hour)**
1. Register hygiene pass: convergence statuses current, no entry missing an expiry, index (GOV-0002) reconciled against merged ADRs.
2. Update the Automation Ledger with any controls that changed verification mode.

**Quarterly (the main event)**
1. T-2 weeks: compile the directive health panel (metrics per GOV-0001 Component 2) onto one page; flag threshold trips.
2. T-1 week: circulate the agenda: register walk items, tripped thresholds, assumption flags, open challenges, automation progress.
3. Run the review to the 90-minute timebox; capture decisions in the moment.
4. T+1 week: publish the one-page summary to all engineering teams, record commissioned revision ADRs with authors and due dates, update all registers with review outcomes.

## Handoff Checklist

The outgoing Steward, before rotation completes:
1. Walks the incoming Steward through every open register entry with its story, not just its status.
2. Transfers alert tooling ownership and verifies alerts fire for the new holder.
3. Rewrites any section of this handbook that no longer matches reality. An inaccurate handbook is a failed handoff.
4. Records the handoff date in the revision history.

## Judgment Calls You Will Face

- **A team asks you whether they need an ADR.** Give them the two-question test from ADR-0001's notes; don't become the approval step. The practice fails if the Steward becomes a gate.
- **An expiry lands mid-quarter with no review nearby.** Escalation doesn't wait for the meeting: route to the approving authority in the matrix (GOV-0004) directly.
- **The quarterly panel shows nothing tripped.** Per GOV-0001, examine skeptically. Sample two or three teams informally: are the feedback channels quiet because things are healthy, or because nobody believes flagging matters?

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Outgoing Steward | Handoff checklist; handbook rewrite as exit obligation |
| Incoming Steward | Owns this document for their rotation |
| Technical Director | Appoints the rotation; recommended cadence six months, so every Steward experiences at least two quarterly reviews |

## Change Discipline

- **Keeping it true:** the current Steward edits freely; this is the most-alive document in the directory by design.
- **Changing how the machinery works:** duties that alter what the registers or reviews do require an ADR against GOV-0001.

## Health

If weekly duties exceed the 30-minute target for a sustained period, that is a finding against the machinery's weight, reported at the quarterly review with a proposed simplification, not absorbed silently.

## Notes

**This draft is a forecast, not experience.** It was written before anyone operated the role. The first outgoing Steward's rewrite at handoff is the real founding of this document; expect them to correct the timebox estimates and the judgment calls list against what the role actually turned out to be.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Pre-operational draft | Technical Director |
