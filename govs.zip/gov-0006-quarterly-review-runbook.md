# GOV-0006: Quarterly Governance Health Review Runbook

| Field | Value |
|---|---|
| **Status** | Draft (activates when operational detail outgrows GOV-0001; see Notes) |
| **Effective Date** | Upon activation |
| **Established By** | GOV-0001 (Component 3 defines the review; this runbook operationalizes it) |
| **Owner** | Governance Steward |
| **Kind** | Operating Procedure |
| **Review Cadence** | Updated after each review where the procedure changed |

## Purpose

The step-by-step mechanics of running the Quarterly Governance Health Review: preparation, execution to the timebox, and publication. The agenda and its rationale live in GOV-0001; this document exists so any Steward can run the review identically without reconstructing the mechanics.

## Preparation (T-2 weeks to T-0)

1. **T-2 weeks, metrics pull.** Assemble the directive health panel: one row per TD with active exceptions, new requests, gate holds and findings, repeat findings, renewal-count-2 entries, verification mode. Sources: GOV-0003 for exception columns, review records for findings, the Automation Ledger for verification mode. One page. If it doesn't fit one page, that's a reportable weight finding, not a formatting problem.
2. **T-2 weeks, threshold marking.** Mark each TD Healthy / Friction / Wrong rule per GOV-0001's interpretation thresholds. Healthy rows get no agenda time.
3. **T-1 week, agenda circulation.** To Council seats and portfolio leads: register walk items (expiring, expired-silent, at-risk, renewal-count-2), tripped thresholds only, triaged assumption flags, open challenges with their one-pagers attached, automation progress since last quarter.
4. **T-1 week, pre-reads.** Portfolio leads owning at-risk register entries confirm they can answer for them; the Steward chases confirmations once.

## Execution (90 minutes, hard stop)

| Segment | Time | Procedure |
|---|---|---|
| Exception Register walk | 20 min | Decision per item: close, renew (increment count), escalate, or refer to revision. No item leaves undecided; undecidable items escalate to the chair by default |
| Directive health panel | 25 min | Tripped rows only. For each: enablement gap, platform gap, or wrong rule? Name the response and its owner |
| Assumption Watch | 15 min | Confirmed-broken assumptions obligate a reaffirm/revise/supersede decision on the ADR, with a named author if revision |
| Challenges and revisions | 20 min | Decide open challenges; check commissioned revision ADRs against due dates |
| Automation Ledger | 10 min | Converted controls acknowledged; next conversion candidates confirmed with owners |

Timekeeping is the Steward's job; the chair decides, the Steward moves the meeting. If the register walk alone threatens the timebox, the monthly Steward hygiene pass (GOV-0005) is failing and that is the finding to raise.

## Publication (T+1 week)

1. One-page summary to all engineering teams: decisions made, rules revised or reaffirmed, exceptions closed, what got simpler. Written for the workforce, not the Council; visible self-correction is the point.
2. Registers updated with every review outcome; commissioned revision ADRs recorded with author and due date in the tracking section below.
3. Any weight findings against the governance system itself logged with a proposed simplification.

## Commissioned Revisions Tracking

| Revision | Commissioned | Author | Due | Status |
|---|---|---|---|---|
| *(none yet)* | | | | |

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Governance Steward | Preparation, timekeeping, publication |
| Technical Director (chair) | Decisions, suspensions, expedites |
| Council seats and portfolio leads | Answer for their items; decide within their rights per GOV-0004 |

## Change Discipline

- **Keeping it true:** the Steward refines procedure steps freely after each review.
- **Changing how the machinery works:** agenda structure, timebox, and threshold semantics belong to GOV-0001 and require an ADR to change.

## Health

Reviews consistently exceeding 90 minutes, or preparation consistently exceeding the GOV-0005 timeboxes, are findings answered by simplification per GOV-0001's self-measurement rules.

## Notes

**Activation trigger:** this runbook stays Draft while GOV-0001's Component 3 suffices, expected through the first two or three reviews. Activate it when mechanics start bloating GOV-0001; at activation, GOV-0001 Component 3 slims to the agenda and its rationale, and points here for procedure.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Pre-activation draft | Technical Director |
