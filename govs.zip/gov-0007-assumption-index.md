# GOV-0007: Assumption Index

| Field | Value |
|---|---|
| **Status** | Draft (content lives as a GOV-0001 appendix until volume triggers the split; see Notes) |
| **Effective Date** | Upon activation |
| **Established By** | GOV-0001 (Component 4, Assumption Watch) |
| **Owner** | Governance Steward |
| **Kind** | Register |
| **Review Cadence** | Flag triage weekly; full walk at the Quarterly Governance Health Review |

## Purpose

The register of material assumptions extracted from accepted ADRs, each with the condition that would break it and the decision it would reopen. Every ADR's Rationale section lists what the decision rests on; this index is how someone is responsible for noticing when one of those conditions changes.

## Schema

| Field | Meaning |
|---|---|
| Assumption ID | AS-NNNN |
| Source ADR | The record whose Rationale states it |
| Assumption | The condition, quoted or tightly paraphrased |
| Break Trigger | The observable event or state that would falsify it |
| Status | Holding / Flagged / Confirmed broken / Resolved |
| Flagged By / Date | Who raised it (any engineer may) |
| Outcome | Reaffirmed / Revised via ADR-NNNN / Superseded by ADR-NNNN |

## The Index (seeded from the founding ADRs)

| Assumption ID | Source ADR | Assumption | Break Trigger | Status |
|---|---|---|---|---|
| AS-0001 | ADR-0001 | Common version control platform available to all teams | A converging team cannot reach the platform | Holding |
| AS-0002 | ADR-0002 | Repository platform renders Mermaid natively | Rendering support dropped or degraded | Holding |
| AS-0003 | ADR-0003 | Capability platforms resourced as products | A platform loses product management or roadmap capacity | Holding |
| AS-0004 | ADR-0004 | User access can be arranged; proxy arrangements are explicit | Direct and proxy access systematically unavailable | Holding |
| AS-0005 | ADR-0005 | Nitro resourced for full organizational build volume | Sustained queue growth or capacity denials | Holding |
| AS-0006 | ADR-0006 | Platforma staffed and managed as a product | Roadmap or staffing lapse; gap-escalation unanswered | Holding |
| AS-0007 | ADR-0007 | Experience design engineering resourced to govern Trenchcoat | Contribution and gap queues unattended a full quarter | Holding |
| AS-0008 | ADR-0008 | Enterprise identity platform operated to enterprise availability and accreditation | Availability breach or accreditation lapse | Holding |

## Operating Rules

1. New accepted ADRs have their material assumptions extracted into this index as part of index registration (GOV-0002 checklist).
2. Any engineer flags a suspected break via a linked issue referencing the ADR; nothing heavier.
3. The Steward triages weekly: Flagged entries either return to Holding with a note or advance to the quarterly agenda.
4. A Confirmed broken assumption obligates a reaffirm/revise/supersede decision on the source ADR. It does not automatically invalidate the decision.
5. Resolved entries record their outcome and remain in the index; the trail of which assumptions broke is itself governance evidence.

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Any engineer | Flag suspected breaks |
| Governance Steward | Extraction, triage, quarterly preparation |
| Architecture Council / Technical Director | The reaffirm/revise/supersede decision per authority matrix |

## Change Discipline

- **Keeping it true:** extraction, triage, and status updates are direct Steward edits.
- **Changing how the machinery works:** Assumption Watch semantics belong to GOV-0001 and require an ADR.

## Health

Every Accepted ADR with a Rationale section has entries here or a recorded "no material assumptions" note. Zero flags across multiple quarters triggers the skeptical sampling rule from GOV-0001.

## Notes

**Deliberately not founded as a standalone document.** The seeded table above lives as an appendix to GOV-0001 at founding. This draft exists to show the graduated form; activate it only when assumption volume makes the host appendix unwieldy. Standing it up on day one would be paperwork theater.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Pre-activation draft with founding assumptions seeded | Technical Director |
