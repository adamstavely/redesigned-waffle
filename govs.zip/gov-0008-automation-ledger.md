# GOV-0008: Automation Ledger

| Field | Value |
|---|---|
| **Status** | Draft (content lives as a GOV-0001 appendix until volume triggers the split; see Notes) |
| **Effective Date** | Upon activation |
| **Established By** | GOV-0001 (Component 6) |
| **Owner** | Governance Steward |
| **Kind** | Register |
| **Review Cadence** | Updated monthly; progress reviewed quarterly |

## Purpose

The register of how every TD obligation is verified today and where its verification is headed. The strategic claim it operationalizes: manual review checks are transitional, and the end state is enforcement living in Nitro, Platforma, and the repository platform, where compliance is automatic and the governance meeting never sees it.

## Schema

| Field | Meaning |
|---|---|
| TD / Statement | e.g., TD-0002 / 3 |
| Current Verification | Automated gate / Review checklist / Audit / Registry |
| Automation Target | The intended machine check, or "None plausible" with the reason |
| Owner / Target Quarter | Who converts it, by when |
| Status | Manual / In conversion / Automated / None plausible |

## The Ledger (seeded from the founding TDs)

| TD / Statement | Current Verification | Automation Target | Status |
|---|---|---|---|
| TD-0005 / 2, 3 (Nitro credentials, provenance) | Automated gate | Already platform-enforced | Automated |
| TD-0006 / 2 (Platforma accepts Nitro only) | Automated gate | Already platform-enforced | Automated |
| TD-0001 / 5 (PRs reference governing ADR) | Review checklist | Repository check: PR template + link linting on labeled changes | Manual |
| TD-0002 / 2, 3 (diagram presence, Mermaid source) | Review checklist | Repository check: structure-changing ADRs must contain/reference Mermaid blocks | Manual |
| TD-0002 / 5 (canonical set vs. reality) | Audit | Partial: existence checkable; drift-vs-deployed likely None plausible near term | Manual |
| TD-0003 / 2 (context map check before build) | Review checklist | Service scaffolding gate in Platforma golden path: declare capability, check map | Manual |
| TD-0007 / 4 (component fork detection) | Review checklist | Dependency scan for diverged local copies of Trenchcoat packages | Manual |
| TD-0008 / 1 (no local user stores) | Security review | Static/dependency scan for local auth patterns; golden-path attestation | Manual |
| TD-0004 / 1-5 (HCD evidence) | Gate review | None plausible: evidence quality is judgment; automate presence-tracking only | None plausible |

## Operating Rules

1. Every TD statement appears here with a verification mode; "we'll check it in review" without a ledger entry is not a verification plan.
2. Conversion priority follows quarterly finding counts: the manual checks consuming the most human attention convert first.
3. "None plausible" is a legitimate status but carries its reason, and is revisited when platform capability changes.
4. Conversions land as golden-path or pipeline changes owned by the platform teams; the ledger tracks, it does not build.

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Governance Steward | Maintains the ledger; prepares quarterly progress |
| Platform teams (Nitro, Platforma, repo platform) | Own conversions on their surfaces |
| Technical Director | Prioritization when conversion demand exceeds platform capacity |

## Change Discipline

- **Keeping it true:** entry and status updates are direct Steward edits; conversion commitments are made by the owning platform team, not entered unilaterally.
- **Changing how the machinery works:** the transitional-manual-checks principle belongs to GOV-0001 and requires an ADR.

## Health

The single trend that matters: the Manual count declining quarter over quarter. A flat Manual count across multiple quarters with rising finding counts is a prioritization finding for the Technical Director.

## Notes

**Deliberately not founded as a standalone document.** The seeded ledger lives as a GOV-0001 appendix at founding; this draft shows the graduated form. Activate when entry volume or conversion tracking outgrows the appendix.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Pre-activation draft with founding TD obligations seeded | Technical Director |
