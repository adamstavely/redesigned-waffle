# GOV-0009: Challenge Log

| Field | Value |
|---|---|
| **Status** | Draft (content lives as a GOV-0004 section until volume triggers the split; see Notes) |
| **Effective Date** | Upon activation |
| **Established By** | GOV-0001 (Component 5, the Challenge Path) |
| **Owner** | Governance Steward (adjudication by Architecture Council) |
| **Kind** | Register |
| **Review Cadence** | Open challenges decided by the next Quarterly Governance Health Review, guaranteed |

## Purpose

The register of petitions to revise or rescind a TD or ADR: what was contested, by whom, on what evidence, and how it was decided. The log exists for two reasons beyond tracking: it makes the decision guarantee auditable (no challenge ages past a review undecided), and it accumulates the reaffirmation record that gives twice-reaffirmed rules their presumption of stability.

## Schema

| Field | Meaning |
|---|---|
| Challenge ID | CH-NNNN |
| Contested | TD-NNNN or ADR-NNNN, and the specific obligation or holding |
| Submitted By / Date | Team and date received |
| Evidence Summary | One line from the one-pager |
| Suspension | Whether the Technical Director suspended the obligation pending decision |
| Decision | Revised via ADR-NNNN / Superseded / Reaffirmed via ADR-NNNN / Withdrawn |
| Decided | Date; must not exceed the next quarterly review after receipt |
| Reaffirmation Count | Per contested rule; 2 raises the new-evidence bar for further challenges |

## The Log

| Challenge ID | Contested | Submitted By | Received | Suspension | Decision | Decided |
|---|---|---|---|---|---|---|
| *(none yet)* | | | | | | |

## Operating Rules

1. Receipt is acknowledged by the Steward within the weekly triage; the challenge is logged on receipt, not on agenda placement.
2. Every challenge is decided by the next quarterly review, or sooner if expedited. A challenge aging past a review undecided is a hard finding against the Council.
3. Every decision lands as an ADR: revision, supersession, or a reaffirmation ADR stating why the rule stands. Reaffirmations are real records, not rubber stamps; they must engage the evidence.
4. Compliance continues while a challenge is pending unless suspension is granted; the log records suspension so enforcement bodies know.
5. Withdrawn challenges are logged with a note; patterns of withdrawal under pressure are a legitimacy signal the Steward raises.
6. Resubmission after rejection requires materially new evidence once a rule is twice reaffirmed.

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| Any team | May submit; one page maximum, per GOV-0001 |
| Governance Steward | Receipt, logging, agenda routing |
| Architecture Council | Decisions, per GOV-0004 decision rights |
| Technical Director | Expedites and suspensions |

## Change Discipline

- **Keeping it true:** log entries are direct Steward edits.
- **Changing how the machinery works:** Challenge Path semantics (the guarantee, the suspension rule, the reaffirmation bar) belong to GOV-0001 and require an ADR.

## Health

Zero challenges across multiple quarters is examined skeptically per GOV-0001: either the rules fit or nobody believes challenging works, and the two look identical from the outside. Decision latency at 100 percent within-guarantee is the hard floor.

## Notes

**Deliberately not founded as a standalone document.** The log table lives in GOV-0004 (Architecture Council Charter) at founding, since the Council owns adjudication and early volume will be low. This draft shows the graduated form; activate when challenge volume makes the charter section unwieldy, which would itself be interesting evidence about the rule set.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Pre-activation draft | Technical Director |
