# GOV-0002: ADR Index

| Field | Value |
|---|---|
| **Status** | In Effect |
| **Effective Date** | 2026-08-17 |
| **Established By** | ADR-0001: Adopt Architecture Decision Records for All Architecture Decisions |
| **Owner** | Governance Steward |
| **Kind** | Register |
| **Review Cadence** | Continuously maintained; completeness audited quarterly at the Governance Health Review |

## Purpose

The front door to the governance graph: the authoritative list of every ADR, its status, and what it generated. A decision not in this index is not discoverable, and TD-0001 makes registration mandatory. This index also answers the two most common navigation questions: "what governs X?" and "is this decision still current?"

## Schema

| Field | Meaning |
|---|---|
| ADR | Number, linked to the file |
| Title | Short title |
| Status | Proposed / Accepted / Deprecated / Superseded by ADR-NNNN |
| Scope | Portfolio, or Cross-cutting |
| Generates | TD-NNNN, STD-NNNN, GOV-NNNN, or blank (most are blank) |
| Type | Decision / Exception (exceptions also carry expiry, tracked in GOV-0003) |

## The Index

| ADR | Title | Status | Scope | Generates | Type |
|---|---|---|---|---|---|
| ADR-0001 | Adopt Architecture Decision Records | Accepted | Cross-cutting | TD-0001, GOV-0002 | Decision |
| ADR-0002 | C4 Model with Mermaid for Architecture Diagrams | Accepted | Cross-cutting | TD-0002, STD-0001 | Decision |
| ADR-0003 | DDD Capability Platforms as the Integrated Service Layer | Accepted | Cross-cutting | TD-0003, STD-0002 | Decision |
| ADR-0004 | Human-Centered Design and Development Practices | Accepted | Cross-cutting | TD-0004, STD-0004 | Decision |
| ADR-0005 | Nitro for All Build, Delivery, and Deployment | Accepted | Cross-cutting | TD-0005 | Decision |
| ADR-0006 | Platform Engineering with Platforma as the IDP | Accepted | Cross-cutting | TD-0006 | Decision |
| ADR-0007 | Trenchcoat Design System with Tiered Design Levels | Accepted | Cross-cutting | TD-0007, STD-0003 | Decision |
| ADR-0008 | Enterprise OAuth, STS, OBO with Externalized Access Control | Accepted | Cross-cutting | TD-0008 | Decision |

## POL Index

Policy positions recommended to external approving authorities, tracked with their dispositions. The POL is our record; only the authority's issued instrument is in effect.

| POL | Title | Authority | Status | Outcome / Instrument | Bound Through |
|---|---|---|---|---|---|
| *(none yet)* | | | | | |

POL operating rules: entries register at submission, dispositions complete when the authority decides, and Approved-with-Modification entries link their delta record. Exceptions clustering against an issued policy's deltas are flagged to the Steward as evidence for the next recommendation cycle.

## Operating Rules

- An ADR is added to the index in the same pull request that merges it; the index entry is part of the ADR review checklist.
- Status changes (acceptance, supersession, deprecation) are reflected here in the same change that alters the record.
- Supersession is recorded in both directions: the old entry's status names its successor, and readers follow the chain from either end.
- Exception ADRs appear here like any other, typed as Exception; their expiry and convergence tracking live in GOV-0003, not here. One fact, one home.

## Roles

| Role | Responsibility in this mechanism |
|---|---|
| ADR authors | Add and update their entries as part of the record's pull request |
| Governance Steward | Audits completeness quarterly against merged records |

## Change Discipline

- **Keeping it true:** entry additions and status updates are direct edits by authors and the Steward.
- **Changing how the machinery works:** schema changes require an ADR revising ADR-0001's practice.

## Health

Completeness: quarterly audit sampling merged ADR files against index entries; any gap is a finding. Staleness: entries whose status disagrees with the record file are findings against the owning team.

## Revision History

| Date | Change | Author |
|---|---|---|
| 2026-08-17 | Initial issuance with founding records ADR-0001 through ADR-0008 | Technical Director |
