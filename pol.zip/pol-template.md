# POL-NNNN: [Short Title of Policy Position]

| Field | Value |
|---|---|
| **Status** | Drafting / Recommended / Approved / Approved with Modification / Declined / Withdrawn / Retired |
| **Approving Authority** | [Who signs, e.g., CISO, Data Governance Board] |
| **Recommended By** | Technical Director |
| **Date Recommended** | YYYY-MM-DD |
| **Date Decided** | YYYY-MM-DD (by the authority) |
| **Issued Instrument** | [Link/citation to the signed policy once issued; the authority's document, not this one] |
| **Bound Through** | [TD that binds teams to the issued policy, e.g., TD-0008; blank until approved] |
| **Related Records** | [Prior POLs, relevant ADRs, exception evidence] |

## Context and Problem Statement

The situation requiring a policy position: what access question is unresolved or resolved badly today, who is affected, and what happens absent a policy. Written to stand alone for the approving authority's staff, who do not live in this repository.

## Recommended Position

The position itself, stated as the authority would issue it: precise, testable, in SHALL form where possible. This section should be liftable directly into the issued instrument. If the position has parts, number them so the authority can adopt selectively and the disposition can be tracked per part.

## Options Considered

The alternatives, including the status quo, each with pros, cons, and risks, exactly as in an ADR. The authority is being asked to choose; show the choice space honestly, including the option of doing nothing.

## Rationale (Why This Position)

The persuasion core, and later the durable record of what we argued:

- **How it addresses the problem:** mapped to the context above.
- **Why the alternatives were not recommended:** one or two sentences each.
- **Tradeoffs acknowledged:** what this position costs, stated before the authority's staff discover it themselves.
- **Operational evidence:** exception patterns, findings, incident history, or platform data supporting the position. Evidence from the Exception Register is the strongest material this section can carry.
- **Assumptions:** conditions that, if changed, should trigger revisiting the position.

## Implementation Sketch

What adoption would require: which TD statements change or bind to the issued policy, which STD or policy-as-code artifacts carry the rules, enforcement mechanism, and a realistic timeline. Authorities approve faster when the path from signature to enforcement is already drawn.

## Disposition

Completed after the authority decides:

- **Outcome:** Approved / Approved with Modification / Declined, with date and instrument reference.
- **Delta record (if modified):** each divergence between the recommended and issued position, and its operational implication. This is the section future exception patterns will be read against.
- **If declined:** the stated reason, and what evidence would justify resubmission.

## Notes

[Submission mechanics, authority staff contacts, resubmission history.]

## Revision History

| Date | Change | Author |
|---|---|---|
| YYYY-MM-DD | Initial draft | [Name] |
