# Policy Positions (POL)

**POLs recommend.** This directory holds policy positions, principally on data access control, that this organization forms and tees up to an external approving authority for signature. We recommend; the authority decides. The POL is our durable record of what we argued, why, and what happened to it.

## The Functional Definition (Read This First)

A POL is not "a document about access control." It is the record type for **a position requiring approval by an authority outside this organization's signature**. That definition is what keeps the taxonomy functional rather than topical: we do not add prefixes per subject (no SEC, no DAT), we add them per function, and recommending-for-external-approval is a genuinely distinct function with its own lifecycle and outcome states. Today's POL volume is data access policy; if tomorrow brings another domain requiring the same recommend-then-approve workflow, it uses this same prefix.

The signature test across the system:
- You'd sign it and it's a decision: **ADR**.
- Someone else signs it and we're arguing for it: **POL**.
- Someone else signed it and it binds us: **external reference**, bound from a TD.

## Lifecycle

| Status | Meaning |
|---|---|
| Drafting | Position being formed; not yet submitted |
| Recommended | Submitted to the authority; the clock is theirs |
| Approved | Issued as recommended; see the Issued Instrument link |
| Approved with Modification | Issued with deltas; the Disposition section records each divergence |
| Declined | Not adopted; the stated reason and resubmission bar are recorded |
| Withdrawn | We pulled it back before decision |
| Retired | The issued policy was later rescinded or superseded |

A POL is never "In Effect." Only the authority's issued instrument is in effect, and our TDs bind to that instrument, not to the POL.

## How to Create One

1. Copy `../templates/pol-template.md`, name it `pol-NNNN-short-kebab-title.md` with the next number from the POL index.
2. Write the Recommended Position so it's liftable directly into the issued instrument, numbered by part so the authority can adopt selectively.
3. Load the Rationale with operational evidence. The Exception Register is your best source: "eleven exceptions against this control in two quarters, here's the pattern" persuades where opinion doesn't. The feedback loop generates this material as a byproduct; use it.
4. Include the Implementation Sketch. Authorities sign faster when the path from signature to enforcement is already drawn.
5. Register the entry in the POL index (GOV-0002) at submission, and complete the Disposition section when the authority decides.

## After the Decision

- **Approved:** the binding TD (usually TD-0008) is updated to reference the issued instrument; rules land as STD content or policy-as-code per ADR-0008. The POL's job is done; it stands as the record.
- **Approved with Modification:** same, plus the delta record. Watch the Exception Register: deviations clustering around a delta are the evidence base for the next recommendation cycle.
- **Declined:** we comply with the status quo and keep operating. Resubmission requires the materially new evidence the Disposition section names; accumulating exception and finding patterns are precisely that evidence.

**We comply with issued policy while advocating to change it.** A POL is never a license to deviate; deviations go through the exception process like everything else, and those exceptions then feed the next POL.

## What a POL Is Not

Not an internal decision softened into a recommendation: internally, you decide (ADR) and the challenge path handles disagreement. Not the live access rules: those are policy-as-code in the enterprise policy layer per ADR-0008. Not the issued policy itself: that is the authority's document, linked from ours.

## Governed By

The establishing ADR for the POL practice, GOV-0002 (POL index with disposition tracking), GOV-0001 (exception evidence feeding the recommendation cycle), and TD-0008 (where approved positions typically bind).
