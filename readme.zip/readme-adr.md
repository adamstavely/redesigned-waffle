# Architecture Decision Records (ADR)

**ADRs decide.** This directory holds the record of every architecturally significant decision: what we chose, what we rejected, and why. ADRs are the root of the governance graph; every TD, STD, and GOV document traces back to one.

## When to Write One

Write an ADR when a decision shapes architecture beyond the moment: it constrains future choices, affects more than your team, changes a system boundary, or is something an engineer two years from now will need the reasoning for. Skip it for local implementation choices (naming, routine refactoring, dependency bumps).

Quick test: **will someone later need to know why?** If yes, record it.

Deviating from a Technical Directive also requires an ADR here: an exception ADR referencing the TD, with an approval authority and an expiry date. Exceptions are first-class records, not workarounds.

## How to Create One

1. Copy `../templates/adr-template.md` into this directory.
2. Name it `adr-NNNN-short-kebab-title.md`, taking the next number from the index. Numbers are never reused.
3. Fill every section. The **Rationale** section is mandatory and is the reason this practice exists: map the choice to the decision drivers, say why each alternative lost, name the tradeoffs accepted, and list the assumptions that should trigger a revisit.
4. Open a pull request. Cross-cutting decisions (more than one portfolio, or any capability platform) route to the Architecture Council for review; others follow normal team review.
5. On merge, add the entry to the ADR index.

## Lifecycle

| Status | Meaning |
|---|---|
| Proposed | Under review, not yet binding |
| Accepted | The decision of record |
| Deprecated | No longer applies; nothing replaced it |
| Superseded by ADR-NNNN | Replaced; the successor says why |

**Accepted ADRs are immutable.** To change direction, write a new ADR that supersedes the old one. The history is the point: superseded records preserve what we believed and when.

## What an ADR Is Not

An ADR does not impose obligations (that's a TD), specify craft detail (that's an STD), or describe governance operations (that's a GOV). Most ADRs generate none of these. A TD is warranted only when the decision binds cross-team behavior and violations would be invisible without a check.

## Governed By

ADR-0001 (the practice), TD-0001 (its enforcement), GOV-0001 (the feedback loop, including Assumption Watch on the assumptions your Rationale section lists).
