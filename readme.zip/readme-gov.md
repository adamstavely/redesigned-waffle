# Governance Operations (GOV)

**GOVs operate.** This directory holds the small set of living documents that keep the governance machinery itself running: the registers, the review rhythm, the charters, and the rules for changing the rules. GOV documents describe how governance works; they do not impose obligations on delivery teams (that's a TD) and they do not record decisions (that's an ADR).

## What Belongs Here

Three kinds of content, and deliberately nothing else:

- **Registers and indexes:** the Exception Register, the Assumption Index, the Automation Ledger, the ADR index, the Challenge Log. The system's memory.
- **Charters:** who decides what. The Architecture Council charter, the Governance Steward handbook, the approval authority matrix.
- **Operating procedures:** how the rhythms run. The Quarterly Governance Health Review runbook, the exception lifecycle procedure, maintained review checklists.

## What Does Not Belong Here

- Craft specifications (diagram rules, design system content, productization criteria): those are **STDs**.
- Estate data (the context map, the tier register, the application registry): those are data owned by their respective TDs and live with their systems. GOV describes the machinery, not the estate.
- Decisions of any kind, including decisions about governance: those are **ADRs**. Every GOV document was established by one.

Keeping this directory small is the point. If it's growing fast, the governance system is getting heavy, and GOV-0001 treats that as a finding.

## The Anchor Document

**GOV-0001: Compliance Tracking and Feedback Loop** defines the operating rhythm everything else supports: the Exception Register rules (expiry alerts, silence-is-escalation, the renewal-count-2 question), the per-TD health metrics and thresholds, the 90-minute quarterly review agenda, Assumption Watch, the Challenge Path, and the Automation Ledger. Read it first; it also carries the full four-layer document interaction model.

## How to Create or Change One

1. A new GOV document requires an establishing ADR: the decision to create the mechanism is recorded there, the mechanism's operating detail lives here.
2. Name it `gov-NNNN-short-kebab-title.md` with the next number.
3. GOV documents are living: the owner (per the document header) edits them directly to keep them true. Structural changes to how the machinery works route through an ADR; keeping a register current does not.

## Roles

| Role | In this directory |
|---|---|
| Governance Steward | Operates the registers, alerts, and review agenda; rotating assignment among principal engineers |
| Architecture Council | Owns charters and adjudication procedures |
| Technical Director | Establishes and revises the machinery via ADR |
| Everyone | May flag assumptions and submit challenges; the procedures here tell you how |

## The Standard This Directory Holds Itself To

From GOV-0001: a quarterly review that runs long is a finding against the governance system. A quarter with zero challenges gets examined skeptically, not celebrated. Governance overhead is sampled, and rising overhead triggers simplification. The machinery measures its own weight by the same standard it applies to everything else.
