# Standards (STD)

**STDs specify.** This directory holds the detailed craft specifications that Technical Directives bind by reference: notation rules, quality bars, required elements, method guides. TDs say *that* you must; STDs say *how*.

## Why Standards Are Separate from Directives

Change velocity. Directives change rarely and are issued by the Technical Director. Standards change often and are maintained by the people closest to the craft: the diagram standard by central engineering, the design system foundations by experience design engineering. Welding fast-moving detail into slow-moving directives would either churn the directives or freeze the standards. Instead, a TD binds to "the current published version" of an STD, and the STD's owner keeps it current without directive-level ceremony.

The prefix answers one question at a glance: **is this document enforceable?** If it's an STD, yes: at least one TD points at it (see the **Bound By** field). Documents without the prefix are advisory.

## When to Create One

Only when a TD needs to bind detailed specification that is better maintained by a domain owner than embedded in the directive. If the detail is short and stable, put it in the TD. If no TD would bind it, it's reference material, not an STD.

## How to Create One

1. Copy `../templates/std-template.md`, name it `std-NNNN-short-kebab-title.md` with the next number.
2. Fill the header: a named **Owner** (team or role, accountable for content), the **Bound By** TDs, and the **Established By** ADR.
3. Write the Specification section however the subject demands. It belongs to the owner; no imposed structure.
4. Publication and subsequent changes are the owner's, under the change control below.

## Change Control (the one guardrail)

- **Clarifying and editorial changes:** the owner makes them freely. Increment the minor version (X.**Y**), add a change note.
- **Material changes** (anything that expands what teams are required to do: new mandatory items, raised bars, new required elements): flag to the Architecture Council or the Quarterly Governance Health Review **before** the change takes effect. Increment the major version (**X**.Y).

The reason: a TD binding "the current published standard" delegates rule-writing to the standard's owner. That delegation is the point, but expansions of obligation get a governance look before they bind anyone.

Every change lands in the Change Note table with its date, version, description, and a Material Y/N marker.

## Lifecycle

| Status | Meaning |
|---|---|
| Draft | Not yet published; nothing binds to it |
| Published | The version TDs bind to |
| Deprecated | No longer bound by any TD |
| Superseded by STD-NNNN | Replaced |

## Governed By

The establishing ADR of each standard, the binding TDs listed in each header, and GOV-0001 (material changes surface at the quarterly review).
