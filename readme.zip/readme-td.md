# Technical Directives (TD)

**TDs oblige.** This directory holds the enforceable obligations of the organization: numbered, testable SHALL statements that implement decisions recorded in ADRs. If an ADR is the statute, the TD is the regulation.

## When to Write One

Rarely. A TD is warranted only when both of these are true:

1. The decision requires teams to do, or stop doing, something.
2. A violation would be invisible without a check.

Most ADRs meet neither test and stand alone. The founding set is eight directives; the count grows slowly by design, because every TD adds standing verification load to the organization.

## How to Create One

1. Confirm the implementing ADR is Accepted. A TD without an ADR behind it does not exist.
2. Copy `../templates/td-template.md`, name it `td-NNNN-short-kebab-title.md` with the next number. TD numbers do not track ADR numbers; the **Implements** field is the authoritative link.
3. Write directive statements as RFC 2119 obligations (SHALL, SHALL NOT, MAY), one obligation per statement, each verifiable by inspection, tooling, or review. If you can't say how a statement would be verified, it isn't ready.
4. Complete the applicability split (new work vs. existing systems), the compliance timeline, the verification mechanism, and the exception approval authority.
5. Issuance is by the Technical Director. Route the pull request accordingly.

## Reading a TD

The rationale is deliberately not here; follow the **Implements** link to the ADR for the why. Where a statement says "per the standard," the referenced STD carries the detail and its current published version is what binds.

## Exceptions and Challenges

- **Your situation doesn't fit the rule:** write an exception ADR referencing the TD, get it approved by the authority named in the TD, give it an expiry date. It takes effect when it lands in the Exception Register (see GOV-0001). This is a legitimate first-class move.
- **You think the rule is wrong:** submit a one-page challenge to the Architecture Council. You are guaranteed a decision by the next quarterly review. Compliance continues while the challenge is pending unless the Technical Director suspends the obligation.

## Lifecycle

| Status | Meaning |
|---|---|
| Draft | Not yet in effect |
| In Effect | Binding per its applicability and timeline |
| Rescinded | Withdrawn; the rescinding decision is an ADR |
| Superseded by TD-NNNN | Replaced |

TDs are versioned and revisable, unlike ADRs. Revisions follow the same issuance path and are logged in the revision history table.

## Governed By

ADR-0001 and TD-0001 (the record system), GOV-0001 (health metrics per TD, exception tracking, the revise-before-enforcing-harder principle).
